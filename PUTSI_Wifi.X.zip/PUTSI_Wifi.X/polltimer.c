/*---------------------------------------------------------------------------
	Project:	      PUTSI WiFi

	Module:		      Allstar Poll timer handler

	File Name:	      polltimer.c

	Author:		      Martin C. Alcock, VE6VH

	Revision:	      1.0

	Description:      Handle the allstar poll timer

            		  Copyright (c) 2018-2022 Praebius Communications Inc.

	Revision History:

---------------------------------------------------------------------------*/
#include "mcc_generated_files/mcc.h"
#include "putsi.h"

// for remote applications, a poll timer is started each time allstar
// sends a poll message. If no message is heard in 30 seconds, the 
// watchdog timer is used to restart the system

#define     POLL_TIMEOUT        50          // 25 second poll timeout
uint8_t     pTimer;                         // poll timer
BOOL        pTimerRunning=FALSE;            // timer is running

// initialize the poll timer
void InitPollTimer(void)
{
    pTimer = POLL_TIMEOUT;
    pTimerRunning = FALSE;
}

// start the poll timer
void StartPollTimer(void)
{
    pTimer = POLL_TIMEOUT;
    pTimerRunning = TRUE;
    COMLed_SetUSBStatus(TRUE);
}

// run timer, called every 0.5 seconds
void RunPollTimer(void)
{
    if(!pTimerRunning)
        return;
    
    pTimer = pTimer - 1;
    
    if(pTimer > 0)
        return;
    
    // timed out; use watchdog to continue
    // stop the timer to allow WD to timeout
    
    timerStop();
    Reset();                   //****************TILT***************
}