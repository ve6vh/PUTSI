/*---------------------------------------------------------------------------
	Project:	      NOAA's ARC

	Module:		      Ex data buffering

	File Name:	      databuffer.c

	Author:		      Martin C. Alcock, VE6VH

	Revision:	      1.05

	Description:	Code for buffering data up to the application layer

					This program is free software: you can redistribute it and/or modify
					it under the terms of the GNU General Public License as published by
					the Free Software Foundation, either version 2 of the License, or
					(at your option) any later version, provided this copyright notice
					is included.

				  Copyright (c) 2018 Praebius Communications Inc.

	Revision History:

---------------------------------------------------------------------------*/
#include <stdio.h>
#include <string.h>

#include "putsi.h"

/*
 * the following apply to large buffers only...
 */
void databuffer_init(DATABUFFER *data_buffer) {

	// initialize the buffer to NO_DATA_RX in case of a pointer runaway
    databuffer_reset(data_buffer);
	for (int i = 0; i < bufferSIZE; i++)
		data_buffer->buffer[i] = BUFFER_NO_DATA;;
}

void databuffer_reset(DATABUFFER *data_buffer) {
	data_buffer->wrptr = data_buffer->rdptr = 0;
    data_buffer->nBytes = 0;    
}

// put a byte in the buffer
void databuffer_put(DATA_ELEMENT byterx, DATABUFFER *data_buffer)
{
	data_buffer->buffer[data_buffer->wrptr] = byterx;
	data_buffer->wrptr = (data_buffer->wrptr + 1) & (bufferSIZE - 1);

    data_buffer->nBytes++;
}

// get a byte from the buffer
DATA_ELEMENT databuffer_get(DATABUFFER *data_buffer)
{
	// take them out here...
	if (data_buffer->nBytes == 0) {
        return BUFFER_NO_DATA;
	}
	DATA_ELEMENT retval = data_buffer->buffer[data_buffer->rdptr];
	data_buffer->rdptr = (data_buffer->rdptr + 1) & (bufferSIZE - 1);
    data_buffer->nBytes--;
	return retval;
}

// see if buffer ends with something...(large buffers only)
BOOL databuffer_endswith(DATABUFFER *data_buffer, const char *tag)
{
    uint8_t tagLen = (uint8_t)(strlen(tag) & 0xff);
    if(data_buffer->nBytes < tagLen)
        return FALSE;           // not enough bytes in buffer
    
    int tagStart = (int)data_buffer->wrptr - (int)tagLen - 1;
    if(tagStart < 0)
        tagStart += bufferSIZE;
    
    for(int i=0;i<tagLen;i++)       {
        DATA_ELEMENT bufByte = data_buffer->buffer[tagStart++];
        if(bufByte != (DATA_ELEMENT)tag[i])
            return FALSE;
    }
    
    return TRUE;
}

/*
 * the following apply to small buffers only...
 */
void databuffer_init_small(SMALLBUFFER *data_buffer) {

	// initialize the buffer to NO_DATA_RX in case of a pointer runaway
    databuffer_reset_small(data_buffer);
	for (int i = 0; i < SMALLbuffer; i++)
		data_buffer->buffer[i] = BUFFER_NO_DATA;;
}

void databuffer_reset_small(SMALLBUFFER *data_buffer) {
	data_buffer->wrptr = data_buffer->rdptr = 0;
    data_buffer->nBytes = 0;    
}

// put a byte in the buffer
void databuffer_put_small(DATA_ELEMENT byterx, SMALLBUFFER *data_buffer)
{
	data_buffer->buffer[data_buffer->wrptr] = byterx;
	data_buffer->wrptr = (data_buffer->wrptr + 1) & (SMALLbuffer - 1);

    data_buffer->nBytes++;
}

// get a byte from the buffer
DATA_ELEMENT databuffer_get_small(SMALLBUFFER *data_buffer)
{
	// take them out here...
	if (data_buffer->nBytes == 0) {
        return BUFFER_NO_DATA;
	}
	DATA_ELEMENT retval = data_buffer->buffer[data_buffer->rdptr];
	data_buffer->rdptr = (data_buffer->rdptr + 1) & (SMALLbuffer - 1);
    data_buffer->nBytes--;
	return retval;
}

