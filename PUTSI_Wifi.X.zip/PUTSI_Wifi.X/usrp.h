/*---------------------------------------------------------------------------
	Project:	      PUTSI WiFi

	Module:		      Main Include file

	Module:		      USRP Packet Definitions

	File Name:	      usrp.h

	Revision:	      0.02

	Description:      Header file for PUTSI project

                      This software module and all others are the exclusive property of the Alberta Digital 
                      Radio Communications Society and others (?the owners?), all rights are reserved.

                      The owners grant licence to any Amateur for personal or club use, and only on hardware
                      designed by them expressly for this purpose, use on any other hardware is prohibited.
 
                      This file, and others may be copied or distributed only with the inclusion of this 
                      notice.

                      No warranty, either express or implied or transfer of rights is granted in this 
                      licence and the owner is not liable for any outcome whatsoever arising from such usage.

                      Copyright � 2023, Alberta Digital Radio Communications Society


	Revision History:

---------------------------------------------------------------------------*/
#pragma once

// tlv type definitions
#define TLV_TAG_BEGIN_TX    0
#define TLV_TAG_AMBE        1
#define TLV_TAG_END_TX      2
#define TLV_TAG_TG_TUNE     3
#define TLV_TAG_PLAY_AMBE   4
#define TLV_TAG_REMOTE_CMD  5
#define TLV_TAG_AMBE_49     6
#define TLV_TAG_AMBE_72     7
#define TLV_TAG_SET_INFO    8
#define TLV_TAG_IMBE        9
#define TLV_TAG_DSAMBE      10
#define TLV_TAG_FILE_XFER   11
#define	TLV_TAG_TELEMETRY	12

// packet types
enum { USRP_TYPE_VOICE=0, USRP_TYPE_DTMF, USRP_TYPE_TEXT, USRP_TYPE_PING, 
        USRP_TYPE_TLV, USRP_TYPE_VOICE_ADPCM, USRP_TYPE_VOICE_ULAW };

// udp data header 
#define EYE_SIZE            4       // sizeof (eye)
struct _chan_usrp_bufhdr {
	char 		eye[EYE_SIZE];	// verification string
	uint32_t 	seq;            // sequence counter
	uint32_t 	memory;         // memory ID or zero (default)
	uint32_t 	keyup;          // tracks PTT state
	uint32_t 	talkgroup;      // trunk TG id
	uint32_t 	type;           // see above enum
	uint32_t 	mpxid;          // for future use
	uint32_t 	reserved;       // for future use
};
typedef struct _chan_usrp_bufhdr USRP_HEADER;

// TLV packet header
struct usrp_tlv_pkt_t	{
	uint8_t		type;		// Type
	uint8_t		length;		// Length
};
typedef struct usrp_tlv_pkt_t TLV_HEADER;

// telemetry TLV sub-types
#define TELEM_TLV_SUB_ANALOG    0       // analog data
#define TELEM_TLV_SUB_DIGIN     1       // digital inputs
#define TELEM_TLV_SUB_DIGOUT    2       // digital outputs

// TLV_telemetry packet struct (used for telemetry)
// uplink packet
struct tlv_telemetry_packet_t	{
	TLV_HEADER  	ADCHeader;                  // Adc header
	ADC_WORD        adc_data[N_ADC];            // ADC data
	TLV_HEADER  	DigInHeader;                // dig in header
	DIG_INPUT       digIn_data[N_INPUTS];       // Digital Inputs data
	TLV_HEADER  	DigOutHeader;               // DigOut header
	DIG_OUTPUT      digOut_data[N_OUTPUTS];     // Digital Outputs data        
};
typedef struct tlv_telemetry_packet_t TLV_TELEMETRY_PACKET;

// outbound telemetry packet
struct _udp_telemetry_packet_t	{
	USRP_HEADER             hdr;    // packet  header
    TLV_HEADER              tlv;    // TLV wrapper
	uint8_t                 radioID[sizeof(uint32_t)];	// radio ID
    TLV_TELEMETRY_PACKET    packet; // telemetry packet
};
typedef struct _udp_telemetry_packet_t UDP_TELEMETRY_PACKET;

// response from server
// downlink packet
struct tlv_telemetry_response_t	{
	TLV_HEADER      DigOutHeader;           // DigOut header
	uint8_t         digOut_data[N_OUTPUTS];	// Digital Outputs data        
};
typedef struct tlv_telemetry_response_t	TLV_RESPONSE;
//
struct _udp_telemetry_response_t	{
	USRP_HEADER     hdr;                        // packet  header
    TLV_HEADER      tlv;                        // TLV wrapper
	uint8_t         radioID[sizeof(uint32_t)];	// radio ID
    TLV_RESPONSE    packet;                     // telemetry packet
};
typedef struct _udp_telemetry_response_t UDP_RESPONSE;

typedef union {
    UDP_RESPONSE    response;                       // response packet
    uint8_t         packet[sizeof(UDP_RESPONSE)];   // packet bytes
} UDP_RESPONSE_PACKET;

