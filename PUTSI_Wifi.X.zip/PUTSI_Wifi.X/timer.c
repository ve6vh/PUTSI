/*---------------------------------------------------------------------------
	Project:	      DAQ imlementation for Allstar

	Module:		      Timer interrupt handler

	File Name:	      timer.c

	Author:		      Martin C. Alcock, VE6VH

	Revision:	      1.05

	Description:      Mainline for DAQ serial monitor

					This program is free software: you can redistribute it and/or modify
					it under the terms of the GNU General Public License as published by
					the Free Software Foundation, either version 2 of the License, or
					(at your option) any later version, provided this copyright notice
					is included.

					Copyright (c) 2018-2022 Praebius Communications Inc.

	Revision History:

---------------------------------------------------------------------------*/
#include "mcc.h"
#include "putsi.h"

// timer runs in increments of 100us
#define     COUNTER_RELOAD          5000           // 0.5 sec between ints

uint32_t    tmrCounter;     // counter as above
uint8_t     delayTime;      // delay time in TMR3 quanta
uint8_t     delaySecs;      // delay time as above

// default message


// start the outer counter and set the interrupt handler
void timerStart(void)
{
    tmrCounter = COUNTER_RELOAD;
    TMR3_SetInterruptHandler(&timerInt);
    TMR3_StartTimer();
    delayTime=0;
}

// stop the timer
void timerStop(void)
{
    TMR3_StopTimer();
}

/* 
 * timer interrupt service routine
 * Cound down interrtups to a 1s timer
 * Queue an 'OK' messaage if Tx is running
 */
void timerInt(void)
{
    // run the USB timer
    USB_Timer();
   
    // delay in quanta of 0.5 second
    if(!tmrCounter)  {
        tmrCounter = COUNTER_RELOAD;
        // run the COM led timer
        COMLed_timer();
        // run the wizfi timer rx timeout timer
        WizFi_rx_timer();
        // run the USRP timer
        USRP_Timer();

        // run the no poll reset timer
        RunPollTimer();

        // delay in quanta of 0.50 sec
        if(delaySecs > 0)
        delaySecs--;            
    }
    tmrCounter--;
    
    // delay in quanta of 100 uSec
    if(delayTime > 0)
       delayTime--;
 }

// programmable delay in quanta of 100usec: max 12ms
void delay(uint8_t time)
{
    if(time == 0)
        return;
    
    // set delay and wait for interrupt to decrement it
    delayTime = time;
    while(delayTime);
    
}

// half second delay
void delaySec(uint8_t secs)
{
    if(secs == 0)
        return;
    
    // set the delay and wait, as above
    delaySecs = secs;
    while(delaySecs);
    
}