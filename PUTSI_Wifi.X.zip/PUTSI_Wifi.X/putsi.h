/*---------------------------------------------------------------------------
	Project:	      PUTSI WiFi

	Module:		      Main Include file

	File Name:	      putsi.h

	Author:		      Martin C. Alcock, VE6VH

	Revision:	      0.02

	Description:      Header file for PUTSI project

                      This software module and all others are the exclusive property of the Alberta Digital 
                      Radio Communications Society and others (?the owners?), all rights are reserved.

                      The owners grant licence to any Amateur for personal or club use, and only on hardware
                      designed by them expressly for this purpose, use on any other hardware is prohibited.
 
                      This file, and others may be copied or distributed only with the inclusion of this 
                      notice.

                      No warranty, either express or implied or transfer of rights is granted in this 
                      licence and the owner is not liable for any outcome whatsoever arising from such usage.

                      Copyright � 2023, Alberta Digital Radio Communications Society


	Revision History:

---------------------------------------------------------------------------*/
#pragma once
#include <stddef.h>
#include <stdint.h>

// inherited from WINDOWS
typedef uint8_t         BOOL;       // boolean type
#define FALSE           0
#define TRUE            1

// data buffer defs
typedef uint8_t			DATA_ELEMENT;		// data element
#define                 BUFFER_EMPTY(x)		(x.nDataBytes == 0)
#define                 BUFFER_NO_DATA		0
#define	bufferSIZE		256                 // large buffer
#define	SMALLbuffer		64                  // small buffer size

// large buffer
struct data_buffer_t {
	uint8_t			wrptr;					// buffer write pointer
	uint8_t			rdptr;					// read pointer
    uint8_t         nBytes;                 // number of bytes held
	DATA_ELEMENT	buffer[bufferSIZE];		// data buffer
};

// small buffer
struct small_buffer_t {
	uint8_t			wrptr;					// buffer write pointer
	uint8_t			rdptr;					// read pointer
    uint8_t         nBytes;                 // number of bytes held
	DATA_ELEMENT	buffer[SMALLbuffer];	// data buffer
};
typedef struct data_buffer_t DATABUFFER;
typedef struct small_buffer_t SMALLBUFFER;

extern SMALLBUFFER usb_rxBuffer;
extern DATABUFFER wifi_rxBuffer;

// setup data
#define MAX_IP_LEN              32          // max IP address length
#define MAX_NAME_SIZE           16          // max name size
#define MAX_FLD_SIZE            8           // sizeof (field)
#define SETUP_MAGIC             0xBEDA      // setup magic number

typedef struct flag_data_t {
    unsigned   WiFiEnabled:1;               // Wifi mode enabled
    unsigned   USBEnabled:1;                // USB mode enabled
    unsigned   AutoConfig:1;                // Auto config mode enabled
} SETUP_FLAGS;

struct setup_data_t {
    char        IPAddress[MAX_IP_LEN];      // IP address           00-1F
    char        SvrPort[MAX_FLD_SIZE];      // port number          20-27
    char        LclPort[MAX_FLD_SIZE];      // local port           28-2F
    char        RadioID[MAX_FLD_SIZE];      // Radio ID             30-38
    char        Interval[MAX_FLD_SIZE];     // reporting interval   38-3F
    char        NetName[MAX_NAME_SIZE];     // AP name
    char        NetPwd[MAX_NAME_SIZE];      // AP password
    SETUP_FLAGS flags;                      // flags
    uint16_t    Magic;                      // magic number: "BEDA" 40-41
}; 
typedef struct setup_data_t SETUP_DATA;

// defs from wizfi.c
// local defines
#define RX_TIMEOUT      2                   // 2 second rx timeout
#define REQ_TIMEOUT     10                  // 10 second HTML timeout
#define DUPLEX_DELAY    2                   // delay in duplex mode
#define SERVER_PORT     80                  // connect to port 80

// WiFi status
#define CONNECTED       2                   // connected
#define TCP_UDP_ACTIVE  3                   // TCP/UDP active
#define DISCONNECTED    4                   // disconnected
#define NO_AP           5                   // no AP

// LED states
#define LED_OFF         0                   // turn LED off
#define LED_RED         1                   // red mode steady
#define LED_RED_FLASH   2                   // red mode flashing
#define LED_GREEN       3                   // green mode steady
#define LED_GREEN_FLASH 4                   // green mode flashing
#define LED_RED_GREEN   5                   // alternate RED/GREEN

// include here to get previous defs...
#include "adc.h"
#include "iodefs.h"
#include "usrp.h"
#include "daq.h"

// references
// from ADC task
void ADC_Task_Start(void);
void ADC_Conv_Update(IO_DATA *io_data);
void ADC_Interrupt(void);
uint8_t ADC_Get8BitValue(uint8_t pin);

// timer
void timerStart(void);
void timerStop(void);
void timerInt(void);
void delay(uint8_t time);
void delaySec(uint8_t secs);

// from COMLed.c
void COMLed_init(void);
void COMLed_timer(void);
void COMLed_SetConfigStatus(bool config);
void COMLed_SetWifiStatus(bool connected);
void COMLed_SetUSBStatus(bool ledstate);

// from databuffer.c
void databuffer_init(DATABUFFER *data_buffer);
void databuffer_reset(DATABUFFER *data_buffer);
void databuffer_put(DATA_ELEMENT byterx, DATABUFFER *data_buffer);
DATA_ELEMENT databuffer_get(DATABUFFER *data_buffer);
BOOL databuffer_endswith(DATABUFFER *data_buffer, const char *tag);
// small buffers
void databuffer_init_small(SMALLBUFFER *data_buffer);
void databuffer_reset_small(SMALLBUFFER *data_buffer);
void databuffer_put_small(DATA_ELEMENT byterx, SMALLBUFFER *data_buffer);
DATA_ELEMENT databuffer_get_small(SMALLBUFFER *data_buffer);

// from usb_rx.c
void USB_Rx(void);

// from WizFi.c
void WizFi_Reset(void);
BOOL WizFi_Init(void);
void Wizfi_Thru_Mode(void);
void WizFi_rx_timer(void);
BOOL WizFi_APSetup(void);
BOOL WizFi_getHTMLReq(void);
void WizFi_Send_Byte(char c, uint8_t spacing);
void WizFi_Send_String(char *cmd, uint8_t spacing);
BOOL WizFi_Send_Uint8(uint8_t *cmd, size_t len, uint8_t spacing);
BOOL Wizfi_Send_TCPData(uint8_t linkID, size_t cmdLen);
BOOL Wizfi_CloseTCP(uint8_t linkID);
BOOL WizFi_APConnect(char *NetName, char *NetPasswd);
BOOL WizFi_ClientSetup(void);
BOOL Wizfi_UDPSetup(char *IPAddress, char *svrport, char *myport);
BOOL Wizfi_Send_UDPData(size_t cmdLen, char *IPAddress, char *port);
BOOL WizFi_getPacket(uint8_t *packet, size_t size, uint8_t timeout);
uint8_t WizFi_BytesInBuffer(void);
DATA_ELEMENT WizFi_get(void);
BOOL WizFi_getResp(char *tag, uint8_t timeout);
BOOL WizFi_hasPacket(char *tag);
uint8_t WizFi_GetConnect_Status(void);

// from io.c
void IO_Task_Start(void);
void IO_Get_Inputs(void);
void IO_Set_Outputs(void);
void IO_Get_Inputs(void);
void IO_Gen_PinMsgs(void);
BOOL InConfigMode(void);
BOOL InThruMode(void);
unsigned getInput(uint8_t pin);
void setOutput(uint8_t pin, BOOL state);
IO_DATA *Get_IO_Data(void);

// from setup.c
BOOL init_setup(void);
SETUP_DATA *Get_Setup(void);
BOOL isWifiEnabled(void);
BOOL isUSBEnabled(void);
BOOL isAutoConfigEnabled(void);
void Write_Setup(void);

// from HTMLStrings.c
BOOL GenHTML(void);
BOOL ProcessHTMLPageReq(void);

// from USRP.c
BOOL USRP_Init(void);
BOOL USRP_Start(void);
void USRP_Timer(void);
BOOL USRP_Get_Timer(void);
BOOL USRP_hasRxPacket(void);
void USRP_SendPacket(IO_DATA *p);
void USRP_GetPacket(IO_DATA *p);

// from utils.c
uint8_t A2_uint8_t(char *s);
uint16_t A2_uint16_t(char *s);
uint32_t A2_uint32_t(char *s);

// from daqMsgProc
void daqMsgProc(DAQ_THREADS *t);
uint8_t getPinDef(uint8_t pinNumber);
void USB_Timer(void);
BOOL USB_Get_Timer(void);
BOOL isUSBTxEnabled(void);
