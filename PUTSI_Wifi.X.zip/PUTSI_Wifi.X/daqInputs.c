/*---------------------------------------------------------------------------
	Project:	      DAQ imlementation for Allstar

	Module:		      Input pin module

	File Name:	      daqInputs.c

	Author:		      Martin C. Alcock, VE6VH

	Revision:	      1.00

	Description:      

    				  Copyright (c) 2018-2022 Praebius Communications Inc.

	Revision History:

---------------------------------------------------------------------------*/
#include "daq.h"
#include "pin_manager.h"

// Pin storage
SYSDEFS *pindefs;               // pin definitions
STACK_ELEMENT pin_msg;

// init the pin manager task
void initInputs(SYSDEFS *pin_defs)
{
    pindefs = pin_defs;
}

void inputPinTask()
{
    uint8_t currentPins = getAllInputs();
    uint8_t pinNums[N_INPUTS], nModPins = 0;
   
    // get the monitored pins
	for (int i = 0; i < N_PINS; i++) {
		PINDEF *pin = getPinDef(i + 1);
		if (pin->flags & PIN_FLAG_MONITOR) {
			pinNums[nModPins++] = pin->pinNum;
		}
	}    
    
    // return if there are no monitored pins
    if(nModPins == 0)
        return;
    
    // check to see if a pin has changed state
    for(int i=0;i<nModPins;i++)     {
        uint8_t pinNum = pinNums[i];
        uint8_t relPin = pinNum-INPUT_START;
        uint8_t pinCond = currentPins & PIN_MASK(relPin);
        PINDEF *pin = getPinDef(pinNum);
        
        // save and switch on the current state
        uint8_t oldpinState = pin->pinState;
        switch(oldpinState)   {
            
            // pin is in the low state
            case PIN_STATE_LOW:
            case PIN_STATE_PULL_LO:
                if(pinCond == 0)
                    break;
                pin->pinState = PIN_STATE_HIGH;
                break;
                
            case PIN_STATE_HIGH:
            case PIN_STATE_PULL_HI:
                if(pinCond > 0)
                    break;
                pin->pinState = PIN_STATE_LOW;
                break;
        }
        
        // change of pin state occurred
        if(pin->pinState != oldpinState)        {
            pin_msg.desig.type = MSG_PIN;
            pin_msg.desig.index = pinNums[i];
            EnQueMsg(pin_msg, TX_NOCHANGE);
        }
    }
}
