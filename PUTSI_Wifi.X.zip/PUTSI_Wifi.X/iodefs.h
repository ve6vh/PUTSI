/*---------------------------------------------------------------------------
	Project:	      PUTSI WiFi

	Module:		      I/O definitions

	File Name:	      iodefs.h

	Revision:	      0.02

	Description:      Header file for PUTSI project

                      This software module and all others are the exclusive property of the Alberta Digital 
                      Radio Communications Society and others (?the owners?), all rights are reserved.

                      The owners grant licence to any Amateur for personal or club use, and only on hardware
                      designed by them expressly for this purpose, use on any other hardware is prohibited.
 
                      This file, and others may be copied or distributed only with the inclusion of this 
                      notice.

                      No warranty, either express or implied or transfer of rights is granted in this 
                      licence and the owner is not liable for any outcome whatsoever arising from such usage.

                      Copyright � 2023, Alberta Digital Radio Communications Society


	Revision History:

---------------------------------------------------------------------------*/
#ifndef IODEFS_H
#define	IODEFS_H

// system defs
#define		N_ADC               8		// number of ADC's
#define     N_INPUTS            5       // number of inputs
#define     N_OUTPUTS           5       // number of outputs

// pin states
#define		PIN_STATE_OFF		0       // pin is off
#define		PIN_STATE_ON		1       // pin is ON

#define     PIN_STATE_NOCHANGE  0       // no change
#define     PIN_STATE_CHANGED   1       // changed
    
#define     PIN_UNMONITORED     0       // unmonitored pin
#define     PIN_MONITORED       1       // pin is monitored    
    
// IO word definitions
typedef adc_result_t    ADC_WORD;       // A/D word

// ADC input struct
typedef struct {
    unsigned    CHANGED :1;             // input has changed
    unsigned    MON     :1;             // is monitored
    unsigned            :6;             // not used
    ADC_WORD    value;                  // current value
} ADC_INPUT;

// digital output
typedef union {
    struct {
        unsigned STATE  :1;                 // current state
        unsigned UPDATE :1;                 // updated state        
        unsigned        :6;        
        };
    uint8_t  BYTE       :8;                 // byte value
} DIG_OUTPUT;

// digital input
typedef union {
    struct {
        unsigned STATE      :1;             // current input state
        unsigned PREV       :1;             // old state
        unsigned CHANGED    :1;             // changed state        
        unsigned MON        :1;             // monitored
        unsigned            :4;
    };
    uint8_t BYTE        :8;
} DIG_INPUT;

// struct holding data collected
struct IOData_t {
	ADC_INPUT       adc_data[N_ADC];            // ADC data
	DIG_INPUT       digIn_data[N_INPUTS];       // Digital Inputs data
	DIG_OUTPUT      digOut_data[N_OUTPUTS];     // Digital Outputs data
};
typedef struct IOData_t IO_DATA;               // struct

// macros
#define     NEXTADC(chan)  (chan + 1) & (N_ADC-1);

// references
// from io.c
BOOL InConfigMode(void);
BOOL InThruMode(void);
unsigned getInput(uint8_t pin);
void setOutput(uint8_t pin, BOOL state);
IO_DATA *Get_IO_Data(void);

#endif	/* IODEFS_H */

