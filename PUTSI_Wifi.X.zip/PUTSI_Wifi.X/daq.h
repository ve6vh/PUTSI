/*---------------------------------------------------------------------------
	Project:	      PUTSI WiFi

	Module:		      Data Acquisition for allstar definitions

	File Name:	      daq.h

	Revision:	      0.02

	Description:      Header file for PUTSI project

                      This software module and all others are the exclusive property of the Alberta Digital 
                      Radio Communications Society and others (?the owners?), all rights are reserved.

                      The owners grant licence to any Amateur for personal or club use, and only on hardware
                      designed by them expressly for this purpose, use on any other hardware is prohibited.
 
                      This file, and others may be copied or distributed only with the inclusion of this 
                      notice.

                      No warranty, either express or implied or transfer of rights is granted in this 
                      licence and the owner is not liable for any outcome whatsoever arising from such usage.

                      Copyright � 2023, Alberta Digital Radio Communications Society


	Revision History:

---------------------------------------------------------------------------*/
#include "iodefs.h"

#pragma once

#ifndef _STDINT_H
#include <stdint.h>
#endif

// system defs
#define		N_ADC               8				// number of ADC's
#define     INPUT_START         N_ADC           // start of input pins
#define     OUTPUT_START        (INPUT_START+N_INPUTS)

// macros
#define		PIN_TO_ADDR(x)		(x-1)               // pin number to address
#define     INPUT_INDEX(x)     (x-1-N_ADC)         // input pin numbers
#define     OUTPUT_INDEX(x)    (x-1-OUTPUT_START)
#define     ISADC(c)            (c < N_ADC)
#define     ISINPUT(c)          ((c >= N_ADC) && (c < OUTPUT_START))
#define     ISOUTPUT(c)         (c>OUTPUT_START)
#define     TOPINNUM(c)         (c+INPUT_START+1)

// DAQ main commands
#define     CMD_RESET   0       // reset PUTSI
#define     CMD_ID		1		// send ID
#define     CMD_LED		2		// turn led ON
#define     CMD_PIN		3		// pin command
#define     CMD_ADC		4		// adc command
#define     N_CMDS		5		// number of commands

// pin comamnds
#define     PIN_IN		0		// set pin as input
#define     PIN_OUT		1		// set pin as output
#define     PIN_MON		2		// monitor pin	
#define     PIN_PULLUP	3		// pull up
#define     PIN_LO		4		// set low
#define     PIN_HI		5		// set high
#define     PIN_ADC     6       // A to D
#define     PIN_UNK     7       // unknown pin number
#define     N_PIN_CMDS	8		// number of pin commands

// struct to hold relevant data
typedef struct daq_threads_t {
	uint8_t         rxstate;			// receiver state
    uint8_t         txReady;            // transmitter state
	DATA_ELEMENT	*msgBuffer;			// buffered message
	int             msgLen;				// message length
    IO_DATA         *ioData;            // Current I/O status
} DAQ_THREADS;

// tx message queue
typedef struct msg_desig_t {
	uint8_t			type;				// type: internal, pin, adc
	uint8_t			index;				// message index
} DESIG;

typedef union stack_element {
	uint16_t		item;				// stack item
	DESIG			desig;				// designator
} STACK_ELEMENT;

#define MK_ELEMENT(x,y) (((uint16_t)(y)<<8)|(uint16_t)x)
#define ELEMENT_TYPE(x) x.desig.type
#define ELEMENT_MSGNUM(x) x.desig.index

// message types
#define		MSG_NOMSG	0       // no message going out
#define		MSG_INT		1       // internal message
#define		MSG_PIN		2       // pin message
#define     MSG_ADC     3       // adc message

// internal messages
#define		INT_NULL	0       // null message (default)
#define		INT_ID		1       // ID response
#define		N_INT		2       // number of internal messages

// arguments to Enque message
#define		TX_NOCHANGE	0		// no change in TX
#define		TX_ON		1		// turn tx on
#define		TX_OFF		2		// turn tx off

// from daqMsgRx.c
BOOL InitUSBMode(IO_DATA *iodata);
void stopDAQRx(void);
void DAQMsgRx(void);

// from daqMsgTx.c
void startDAQTx(DAQ_THREADS *defs);
void stopDAQTx(void);
void DAQMsgTx(void);
BOOL EnQueMsg(STACK_ELEMENT ele, uint8_t txstat);

// from polltimer.c
void InitPollTimer(void);
void StartPollTimer(void);
void RunPollTimer(void);


