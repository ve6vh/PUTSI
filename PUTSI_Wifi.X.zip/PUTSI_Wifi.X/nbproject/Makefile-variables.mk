#
# Generated - do not edit!
#
# NOCDDL
#
CND_BASEDIR=`pwd`
# Wifi_Only configuration
CND_ARTIFACT_DIR_Wifi_Only=dist/Wifi_Only/production
CND_ARTIFACT_NAME_Wifi_Only=PUTSI_Wifi.X.production.hex
CND_ARTIFACT_PATH_Wifi_Only=dist/Wifi_Only/production/PUTSI_Wifi.X.production.hex
# Wifi_and_USB configuration
CND_ARTIFACT_DIR_Wifi_and_USB=dist/Wifi_and_USB/production
CND_ARTIFACT_NAME_Wifi_and_USB=PUTSI_Wifi.X.production.hex
CND_ARTIFACT_PATH_Wifi_and_USB=dist/Wifi_and_USB/production/PUTSI_Wifi.X.production.hex
