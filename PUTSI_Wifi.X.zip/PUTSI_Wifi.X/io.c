/*---------------------------------------------------------------------------
	Project:	      PUTSI WiFi

	Module:		      Pin physical I/O

	File Name:	      Io.c

	Author:		      Martin C. Alcock, VE6VH

	Revision:	      1.00

	Description:      Do the physical I/O to input and output pins

    				  Copyright (c) 2018-2022 Praebius Communications Inc.

	Revision History:

---------------------------------------------------------------------------*/
#include "putsi.h"
#include "pin_manager.h"
#include "adc.h"

// initial values are for test purposes: normally overwritten
const IO_DATA IOData_init = {
    .adc_data = { 
        { PIN_STATE_NOCHANGE, PIN_UNMONITORED, 0x11 },
        { PIN_STATE_NOCHANGE, PIN_UNMONITORED, 0x12 },
        { PIN_STATE_NOCHANGE, PIN_UNMONITORED, 0x13 },
        { PIN_STATE_NOCHANGE, PIN_UNMONITORED, 0x14 },
        { PIN_STATE_NOCHANGE, PIN_UNMONITORED, 0x15 },
        { PIN_STATE_NOCHANGE, PIN_UNMONITORED, 0x16 },
        { PIN_STATE_NOCHANGE, PIN_UNMONITORED, 0x17 },
        { PIN_STATE_NOCHANGE, PIN_UNMONITORED, 0x18 },
    },    
    .digIn_data = {  
        { PIN_STATE_OFF, PIN_STATE_OFF, PIN_STATE_NOCHANGE, PIN_MONITORED },
        { PIN_STATE_OFF, PIN_STATE_OFF, PIN_STATE_NOCHANGE, PIN_MONITORED },
        { PIN_STATE_OFF, PIN_STATE_OFF, PIN_STATE_NOCHANGE, PIN_MONITORED },
        { PIN_STATE_OFF, PIN_STATE_OFF, PIN_STATE_NOCHANGE, PIN_MONITORED },
        { PIN_STATE_OFF, PIN_STATE_OFF, PIN_STATE_NOCHANGE, PIN_MONITORED }
    },
    .digOut_data = {
        { PIN_STATE_OFF, PIN_STATE_OFF },     
        { PIN_STATE_OFF, PIN_STATE_OFF },        
        { PIN_STATE_OFF, PIN_STATE_OFF },        
        { PIN_STATE_OFF, PIN_STATE_OFF },        
        { PIN_STATE_OFF, PIN_STATE_OFF }
    }
};

IO_DATA IOData;             // version in RAM

// get the I/O data struct
IO_DATA *Get_IO_Data(void)
{
    return &IOData;
}

// start the I/O task
void IO_Task_Start(void)
{
    uint8_t i;
    for(i=0;i<N_INPUTS;i++)
        IOData.digIn_data[i].BYTE = IOData_init.digIn_data[i].BYTE;
    
    for(i=0;i<N_OUTPUTS;i++)
        IOData.digOut_data[i].BYTE = IOData_init.digOut_data[i].BYTE;    
    
    for(i=0;i<N_ADC;i++)
        IOData.adc_data[i] = IOData_init.adc_data[i];    
        
}

// scan inputs
void IO_Get_Inputs(void)
{
    uint8_t i;

    for(i=0;i<N_INPUTS;i++) {
        IOData.digIn_data[i].STATE = getInput(i)&PIN_STATE_ON;
        if(IOData.digIn_data[i].PREV ^ IOData.digIn_data[i].STATE)  {
            IOData.digIn_data[i].CHANGED = PIN_STATE_CHANGED;
            IOData.digIn_data[i].PREV = IOData.digIn_data[i].STATE;
        }
    }
}

void IO_Gen_PinMsgs(void)
{
    uint8_t i;
    STACK_ELEMENT io_msg;
    
    for(i=0;i<N_INPUTS;i++) {
        if((IOData.digIn_data[i].CHANGED) && 
           (IOData.digIn_data[i].MON)) {
            io_msg.desig.index = i;
            io_msg.desig.type = MSG_PIN;
            EnQueMsg(io_msg, TX_NOCHANGE);   
            IOData.digIn_data[i].CHANGED = PIN_STATE_NOCHANGE;
        }  
    }
}

// set outputs
void IO_Set_Outputs(void)
{
    uint8_t i;
    
    for(i=0;i<N_OUTPUTS;i++) {
        if(IOData.digOut_data[i].UPDATE)    {
            setOutput(i, IOData.digOut_data[i].STATE);
            IOData.digOut_data[i].UPDATE = 0;
        }
    }
}

// see if we are in config mode
BOOL InConfigMode(void)
{
    if(CONF_GetValue() == 0)
        return TRUE;
    
    return FALSE;
}

// see if we are in pass-thru mode
BOOL InThruMode(void)
{
    if(THRU_GetValue() == 0)
        return TRUE;
    
    return FALSE;
}

// get an input pin value
// NB pin numbers are relative to zero (start at 1!!)
unsigned getInput(uint8_t pin)
{
    // pins are low active..
    switch(pin) {
        
        case 0:
            return SENSE_1_GetValue() ? PIN_STATE_OFF : PIN_STATE_ON;
            
        case 1:
            return SENSE_2_GetValue() ? PIN_STATE_OFF : PIN_STATE_ON;

        case 2:
            return SENSE_3_GetValue() ? PIN_STATE_OFF : PIN_STATE_ON;
            
        case 3:
            return SENSE_4_GetValue() ? PIN_STATE_OFF : PIN_STATE_ON;

        case 4:
            return SENSE_5_GetValue() ? PIN_STATE_OFF : PIN_STATE_ON;
            
    }
    return 0;
}

// set an output pin to a known state
void setOutput(uint8_t pin, BOOL state)
{
    switch (pin)    {
        
        case 0:
            if(state)
                OUT_0_SetHigh();
            else
                OUT_0_SetLow();
            break;
        
        case 1:
            if(state)
                OUT_1_SetHigh();
            else
                OUT_1_SetLow();
            break;
            
        case 2:
            if(state)
                OUT_2_SetHigh();
            else
                OUT_2_SetLow();
            break;
            
        case 3:
            if(state)
                OUT_3_SetHigh();
            else
                OUT_3_SetLow();
            break;
            
        case 4:
            if(state)
                OUT_4_SetHigh();
            else
                OUT_4_SetLow();
            break;

        default:
            break;
    }
    return;
}    