/**
  @Generated Pin Manager Header File

  @Company:
    Microchip Technology Inc.

  @File Name:
    pin_manager.h

  @Summary:
    This is the Pin Manager file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  @Description
    This header file provides APIs for driver for .
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.76
        Device            :  PIC18F45K50
        Driver Version    :  2.11
    The generated drivers are tested against the following:
        Compiler          :  XC8 2.00 and above
        MPLAB 	          :  MPLAB X 5.10	
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#ifndef PIN_MANAGER_H
#define PIN_MANAGER_H

/**
  Section: Included Files
*/

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set SENSE_1 aliases
#define SENSE_1_TRIS                 TRISAbits.TRISA0
#define SENSE_1_LAT                  LATAbits.LATA0
#define SENSE_1_PORT                 PORTAbits.RA0
#define SENSE_1_ANS                  ANSELAbits.ANSA0
#define SENSE_1_SetHigh()            do { LATAbits.LATA0 = 1; } while(0)
#define SENSE_1_SetLow()             do { LATAbits.LATA0 = 0; } while(0)
#define SENSE_1_Toggle()             do { LATAbits.LATA0 = ~LATAbits.LATA0; } while(0)
#define SENSE_1_GetValue()           PORTAbits.RA0
#define SENSE_1_SetDigitalInput()    do { TRISAbits.TRISA0 = 1; } while(0)
#define SENSE_1_SetDigitalOutput()   do { TRISAbits.TRISA0 = 0; } while(0)
#define SENSE_1_SetAnalogMode()      do { ANSELAbits.ANSA0 = 1; } while(0)
#define SENSE_1_SetDigitalMode()     do { ANSELAbits.ANSA0 = 0; } while(0)

// get/set SENSE_2 aliases
#define SENSE_2_TRIS                 TRISAbits.TRISA1
#define SENSE_2_LAT                  LATAbits.LATA1
#define SENSE_2_PORT                 PORTAbits.RA1
#define SENSE_2_ANS                  ANSELAbits.ANSA1
#define SENSE_2_SetHigh()            do { LATAbits.LATA1 = 1; } while(0)
#define SENSE_2_SetLow()             do { LATAbits.LATA1 = 0; } while(0)
#define SENSE_2_Toggle()             do { LATAbits.LATA1 = ~LATAbits.LATA1; } while(0)
#define SENSE_2_GetValue()           PORTAbits.RA1
#define SENSE_2_SetDigitalInput()    do { TRISAbits.TRISA1 = 1; } while(0)
#define SENSE_2_SetDigitalOutput()   do { TRISAbits.TRISA1 = 0; } while(0)
#define SENSE_2_SetAnalogMode()      do { ANSELAbits.ANSA1 = 1; } while(0)
#define SENSE_2_SetDigitalMode()     do { ANSELAbits.ANSA1 = 0; } while(0)

// get/set SENSE_3 aliases
#define SENSE_3_TRIS                 TRISAbits.TRISA2
#define SENSE_3_LAT                  LATAbits.LATA2
#define SENSE_3_PORT                 PORTAbits.RA2
#define SENSE_3_ANS                  ANSELAbits.ANSA2
#define SENSE_3_SetHigh()            do { LATAbits.LATA2 = 1; } while(0)
#define SENSE_3_SetLow()             do { LATAbits.LATA2 = 0; } while(0)
#define SENSE_3_Toggle()             do { LATAbits.LATA2 = ~LATAbits.LATA2; } while(0)
#define SENSE_3_GetValue()           PORTAbits.RA2
#define SENSE_3_SetDigitalInput()    do { TRISAbits.TRISA2 = 1; } while(0)
#define SENSE_3_SetDigitalOutput()   do { TRISAbits.TRISA2 = 0; } while(0)
#define SENSE_3_SetAnalogMode()      do { ANSELAbits.ANSA2 = 1; } while(0)
#define SENSE_3_SetDigitalMode()     do { ANSELAbits.ANSA2 = 0; } while(0)

// get/set SENSE_4 aliases
#define SENSE_4_TRIS                 TRISAbits.TRISA3
#define SENSE_4_LAT                  LATAbits.LATA3
#define SENSE_4_PORT                 PORTAbits.RA3
#define SENSE_4_ANS                  ANSELAbits.ANSA3
#define SENSE_4_SetHigh()            do { LATAbits.LATA3 = 1; } while(0)
#define SENSE_4_SetLow()             do { LATAbits.LATA3 = 0; } while(0)
#define SENSE_4_Toggle()             do { LATAbits.LATA3 = ~LATAbits.LATA3; } while(0)
#define SENSE_4_GetValue()           PORTAbits.RA3
#define SENSE_4_SetDigitalInput()    do { TRISAbits.TRISA3 = 1; } while(0)
#define SENSE_4_SetDigitalOutput()   do { TRISAbits.TRISA3 = 0; } while(0)
#define SENSE_4_SetAnalogMode()      do { ANSELAbits.ANSA3 = 1; } while(0)
#define SENSE_4_SetDigitalMode()     do { ANSELAbits.ANSA3 = 0; } while(0)

// get/set SENSE_5 aliases
#define SENSE_5_TRIS                 TRISAbits.TRISA4
#define SENSE_5_LAT                  LATAbits.LATA4
#define SENSE_5_PORT                 PORTAbits.RA4
#define SENSE_5_SetHigh()            do { LATAbits.LATA4 = 1; } while(0)
#define SENSE_5_SetLow()             do { LATAbits.LATA4 = 0; } while(0)
#define SENSE_5_Toggle()             do { LATAbits.LATA4 = ~LATAbits.LATA4; } while(0)
#define SENSE_5_GetValue()           PORTAbits.RA4
#define SENSE_5_SetDigitalInput()    do { TRISAbits.TRISA4 = 1; } while(0)
#define SENSE_5_SetDigitalOutput()   do { TRISAbits.TRISA4 = 0; } while(0)

// get/set COM aliases
#define COM_TRIS                 TRISAbits.TRISA5
#define COM_LAT                  LATAbits.LATA5
#define COM_PORT                 PORTAbits.RA5
#define COM_ANS                  ANSELAbits.ANSA5
#define COM_SetHigh()            do { LATAbits.LATA5 = 1; } while(0)
#define COM_SetLow()             do { LATAbits.LATA5 = 0; } while(0)
#define COM_Toggle()             do { LATAbits.LATA5 = ~LATAbits.LATA5; } while(0)
#define COM_GetValue()           PORTAbits.RA5
#define COM_SetDigitalInput()    do { TRISAbits.TRISA5 = 1; } while(0)
#define COM_SetDigitalOutput()   do { TRISAbits.TRISA5 = 0; } while(0)
#define COM_SetAnalogMode()      do { ANSELAbits.ANSA5 = 1; } while(0)
#define COM_SetDigitalMode()     do { ANSELAbits.ANSA5 = 0; } while(0)

// get/set COM_CATH aliases
#define COM_CATH_TRIS                 TRISAbits.TRISA6
#define COM_CATH_LAT                  LATAbits.LATA6
#define COM_CATH_PORT                 PORTAbits.RA6
#define COM_CATH_SetHigh()            do { LATAbits.LATA6 = 1; } while(0)
#define COM_CATH_SetLow()             do { LATAbits.LATA6 = 0; } while(0)
#define COM_CATH_Toggle()             do { LATAbits.LATA6 = ~LATAbits.LATA6; } while(0)
#define COM_CATH_GetValue()           PORTAbits.RA6
#define COM_CATH_SetDigitalInput()    do { TRISAbits.TRISA6 = 1; } while(0)
#define COM_CATH_SetDigitalOutput()   do { TRISAbits.TRISA6 = 0; } while(0)

// get/set COM_ANODE aliases
#define COM_ANODE_TRIS                 TRISAbits.TRISA7
#define COM_ANODE_LAT                  LATAbits.LATA7
#define COM_ANODE_PORT                 PORTAbits.RA7
#define COM_ANODE_SetHigh()            do { LATAbits.LATA7 = 1; } while(0)
#define COM_ANODE_SetLow()             do { LATAbits.LATA7 = 0; } while(0)
#define COM_ANODE_Toggle()             do { LATAbits.LATA7 = ~LATAbits.LATA7; } while(0)
#define COM_ANODE_GetValue()           PORTAbits.RA7
#define COM_ANODE_SetDigitalInput()    do { TRISAbits.TRISA7 = 1; } while(0)
#define COM_ANODE_SetDigitalOutput()   do { TRISAbits.TRISA7 = 0; } while(0)

// get/set OUT_0 aliases
#define OUT_0_TRIS                 TRISBbits.TRISB0
#define OUT_0_LAT                  LATBbits.LATB0
#define OUT_0_PORT                 PORTBbits.RB0
#define OUT_0_WPU                  WPUBbits.WPUB0
#define OUT_0_ANS                  ANSELBbits.ANSB0
#define OUT_0_SetHigh()            do { LATBbits.LATB0 = 1; } while(0)
#define OUT_0_SetLow()             do { LATBbits.LATB0 = 0; } while(0)
#define OUT_0_Toggle()             do { LATBbits.LATB0 = ~LATBbits.LATB0; } while(0)
#define OUT_0_GetValue()           PORTBbits.RB0
#define OUT_0_SetDigitalInput()    do { TRISBbits.TRISB0 = 1; } while(0)
#define OUT_0_SetDigitalOutput()   do { TRISBbits.TRISB0 = 0; } while(0)
#define OUT_0_SetPullup()          do { WPUBbits.WPUB0 = 1; } while(0)
#define OUT_0_ResetPullup()        do { WPUBbits.WPUB0 = 0; } while(0)
#define OUT_0_SetAnalogMode()      do { ANSELBbits.ANSB0 = 1; } while(0)
#define OUT_0_SetDigitalMode()     do { ANSELBbits.ANSB0 = 0; } while(0)

// get/set OUT_1 aliases
#define OUT_1_TRIS                 TRISBbits.TRISB1
#define OUT_1_LAT                  LATBbits.LATB1
#define OUT_1_PORT                 PORTBbits.RB1
#define OUT_1_WPU                  WPUBbits.WPUB1
#define OUT_1_ANS                  ANSELBbits.ANSB1
#define OUT_1_SetHigh()            do { LATBbits.LATB1 = 1; } while(0)
#define OUT_1_SetLow()             do { LATBbits.LATB1 = 0; } while(0)
#define OUT_1_Toggle()             do { LATBbits.LATB1 = ~LATBbits.LATB1; } while(0)
#define OUT_1_GetValue()           PORTBbits.RB1
#define OUT_1_SetDigitalInput()    do { TRISBbits.TRISB1 = 1; } while(0)
#define OUT_1_SetDigitalOutput()   do { TRISBbits.TRISB1 = 0; } while(0)
#define OUT_1_SetPullup()          do { WPUBbits.WPUB1 = 1; } while(0)
#define OUT_1_ResetPullup()        do { WPUBbits.WPUB1 = 0; } while(0)
#define OUT_1_SetAnalogMode()      do { ANSELBbits.ANSB1 = 1; } while(0)
#define OUT_1_SetDigitalMode()     do { ANSELBbits.ANSB1 = 0; } while(0)

// get/set OUT_2 aliases
#define OUT_2_TRIS                 TRISBbits.TRISB2
#define OUT_2_LAT                  LATBbits.LATB2
#define OUT_2_PORT                 PORTBbits.RB2
#define OUT_2_WPU                  WPUBbits.WPUB2
#define OUT_2_ANS                  ANSELBbits.ANSB2
#define OUT_2_SetHigh()            do { LATBbits.LATB2 = 1; } while(0)
#define OUT_2_SetLow()             do { LATBbits.LATB2 = 0; } while(0)
#define OUT_2_Toggle()             do { LATBbits.LATB2 = ~LATBbits.LATB2; } while(0)
#define OUT_2_GetValue()           PORTBbits.RB2
#define OUT_2_SetDigitalInput()    do { TRISBbits.TRISB2 = 1; } while(0)
#define OUT_2_SetDigitalOutput()   do { TRISBbits.TRISB2 = 0; } while(0)
#define OUT_2_SetPullup()          do { WPUBbits.WPUB2 = 1; } while(0)
#define OUT_2_ResetPullup()        do { WPUBbits.WPUB2 = 0; } while(0)
#define OUT_2_SetAnalogMode()      do { ANSELBbits.ANSB2 = 1; } while(0)
#define OUT_2_SetDigitalMode()     do { ANSELBbits.ANSB2 = 0; } while(0)

// get/set OUT_3 aliases
#define OUT_3_TRIS                 TRISBbits.TRISB3
#define OUT_3_LAT                  LATBbits.LATB3
#define OUT_3_PORT                 PORTBbits.RB3
#define OUT_3_WPU                  WPUBbits.WPUB3
#define OUT_3_ANS                  ANSELBbits.ANSB3
#define OUT_3_SetHigh()            do { LATBbits.LATB3 = 1; } while(0)
#define OUT_3_SetLow()             do { LATBbits.LATB3 = 0; } while(0)
#define OUT_3_Toggle()             do { LATBbits.LATB3 = ~LATBbits.LATB3; } while(0)
#define OUT_3_GetValue()           PORTBbits.RB3
#define OUT_3_SetDigitalInput()    do { TRISBbits.TRISB3 = 1; } while(0)
#define OUT_3_SetDigitalOutput()   do { TRISBbits.TRISB3 = 0; } while(0)
#define OUT_3_SetPullup()          do { WPUBbits.WPUB3 = 1; } while(0)
#define OUT_3_ResetPullup()        do { WPUBbits.WPUB3 = 0; } while(0)
#define OUT_3_SetAnalogMode()      do { ANSELBbits.ANSB3 = 1; } while(0)
#define OUT_3_SetDigitalMode()     do { ANSELBbits.ANSB3 = 0; } while(0)

// get/set OUT_4 aliases
#define OUT_4_TRIS                 TRISBbits.TRISB4
#define OUT_4_LAT                  LATBbits.LATB4
#define OUT_4_PORT                 PORTBbits.RB4
#define OUT_4_WPU                  WPUBbits.WPUB4
#define OUT_4_ANS                  ANSELBbits.ANSB4
#define OUT_4_SetHigh()            do { LATBbits.LATB4 = 1; } while(0)
#define OUT_4_SetLow()             do { LATBbits.LATB4 = 0; } while(0)
#define OUT_4_Toggle()             do { LATBbits.LATB4 = ~LATBbits.LATB4; } while(0)
#define OUT_4_GetValue()           PORTBbits.RB4
#define OUT_4_SetDigitalInput()    do { TRISBbits.TRISB4 = 1; } while(0)
#define OUT_4_SetDigitalOutput()   do { TRISBbits.TRISB4 = 0; } while(0)
#define OUT_4_SetPullup()          do { WPUBbits.WPUB4 = 1; } while(0)
#define OUT_4_ResetPullup()        do { WPUBbits.WPUB4 = 0; } while(0)
#define OUT_4_SetAnalogMode()      do { ANSELBbits.ANSB4 = 1; } while(0)
#define OUT_4_SetDigitalMode()     do { ANSELBbits.ANSB4 = 0; } while(0)

// get/set RC1 procedures
#define RC1_SetHigh()            do { LATCbits.LATC1 = 1; } while(0)
#define RC1_SetLow()             do { LATCbits.LATC1 = 0; } while(0)
#define RC1_Toggle()             do { LATCbits.LATC1 = ~LATCbits.LATC1; } while(0)
#define RC1_GetValue()              PORTCbits.RC1
#define RC1_SetDigitalInput()    do { TRISCbits.TRISC1 = 1; } while(0)
#define RC1_SetDigitalOutput()   do { TRISCbits.TRISC1 = 0; } while(0)

// get/set RC6 procedures
#define RC6_SetHigh()            do { LATCbits.LATC6 = 1; } while(0)
#define RC6_SetLow()             do { LATCbits.LATC6 = 0; } while(0)
#define RC6_Toggle()             do { LATCbits.LATC6 = ~LATCbits.LATC6; } while(0)
#define RC6_GetValue()              PORTCbits.RC6
#define RC6_SetDigitalInput()    do { TRISCbits.TRISC6 = 1; } while(0)
#define RC6_SetDigitalOutput()   do { TRISCbits.TRISC6 = 0; } while(0)
#define RC6_SetAnalogMode()         do { ANSELCbits.ANSC6 = 1; } while(0)
#define RC6_SetDigitalMode()        do { ANSELCbits.ANSC6 = 0; } while(0)

// get/set RC7 procedures
#define RC7_SetHigh()            do { LATCbits.LATC7 = 1; } while(0)
#define RC7_SetLow()             do { LATCbits.LATC7 = 0; } while(0)
#define RC7_Toggle()             do { LATCbits.LATC7 = ~LATCbits.LATC7; } while(0)
#define RC7_GetValue()              PORTCbits.RC7
#define RC7_SetDigitalInput()    do { TRISCbits.TRISC7 = 1; } while(0)
#define RC7_SetDigitalOutput()   do { TRISCbits.TRISC7 = 0; } while(0)
#define RC7_SetAnalogMode()         do { ANSELCbits.ANSC7 = 1; } while(0)
#define RC7_SetDigitalMode()        do { ANSELCbits.ANSC7 = 0; } while(0)

// get/set ANA_0 aliases
#define ANA_0_TRIS                 TRISDbits.TRISD0
#define ANA_0_LAT                  LATDbits.LATD0
#define ANA_0_PORT                 PORTDbits.RD0
#define ANA_0_ANS                  ANSELDbits.ANSD0
#define ANA_0_SetHigh()            do { LATDbits.LATD0 = 1; } while(0)
#define ANA_0_SetLow()             do { LATDbits.LATD0 = 0; } while(0)
#define ANA_0_Toggle()             do { LATDbits.LATD0 = ~LATDbits.LATD0; } while(0)
#define ANA_0_GetValue()           PORTDbits.RD0
#define ANA_0_SetDigitalInput()    do { TRISDbits.TRISD0 = 1; } while(0)
#define ANA_0_SetDigitalOutput()   do { TRISDbits.TRISD0 = 0; } while(0)
#define ANA_0_SetAnalogMode()      do { ANSELDbits.ANSD0 = 1; } while(0)
#define ANA_0_SetDigitalMode()     do { ANSELDbits.ANSD0 = 0; } while(0)

// get/set ANA_1 aliases
#define ANA_1_TRIS                 TRISDbits.TRISD1
#define ANA_1_LAT                  LATDbits.LATD1
#define ANA_1_PORT                 PORTDbits.RD1
#define ANA_1_ANS                  ANSELDbits.ANSD1
#define ANA_1_SetHigh()            do { LATDbits.LATD1 = 1; } while(0)
#define ANA_1_SetLow()             do { LATDbits.LATD1 = 0; } while(0)
#define ANA_1_Toggle()             do { LATDbits.LATD1 = ~LATDbits.LATD1; } while(0)
#define ANA_1_GetValue()           PORTDbits.RD1
#define ANA_1_SetDigitalInput()    do { TRISDbits.TRISD1 = 1; } while(0)
#define ANA_1_SetDigitalOutput()   do { TRISDbits.TRISD1 = 0; } while(0)
#define ANA_1_SetAnalogMode()      do { ANSELDbits.ANSD1 = 1; } while(0)
#define ANA_1_SetDigitalMode()     do { ANSELDbits.ANSD1 = 0; } while(0)

// get/set ANA_2 aliases
#define ANA_2_TRIS                 TRISDbits.TRISD2
#define ANA_2_LAT                  LATDbits.LATD2
#define ANA_2_PORT                 PORTDbits.RD2
#define ANA_2_ANS                  ANSELDbits.ANSD2
#define ANA_2_SetHigh()            do { LATDbits.LATD2 = 1; } while(0)
#define ANA_2_SetLow()             do { LATDbits.LATD2 = 0; } while(0)
#define ANA_2_Toggle()             do { LATDbits.LATD2 = ~LATDbits.LATD2; } while(0)
#define ANA_2_GetValue()           PORTDbits.RD2
#define ANA_2_SetDigitalInput()    do { TRISDbits.TRISD2 = 1; } while(0)
#define ANA_2_SetDigitalOutput()   do { TRISDbits.TRISD2 = 0; } while(0)
#define ANA_2_SetAnalogMode()      do { ANSELDbits.ANSD2 = 1; } while(0)
#define ANA_2_SetDigitalMode()     do { ANSELDbits.ANSD2 = 0; } while(0)

// get/set ANA_3 aliases
#define ANA_3_TRIS                 TRISDbits.TRISD3
#define ANA_3_LAT                  LATDbits.LATD3
#define ANA_3_PORT                 PORTDbits.RD3
#define ANA_3_ANS                  ANSELDbits.ANSD3
#define ANA_3_SetHigh()            do { LATDbits.LATD3 = 1; } while(0)
#define ANA_3_SetLow()             do { LATDbits.LATD3 = 0; } while(0)
#define ANA_3_Toggle()             do { LATDbits.LATD3 = ~LATDbits.LATD3; } while(0)
#define ANA_3_GetValue()           PORTDbits.RD3
#define ANA_3_SetDigitalInput()    do { TRISDbits.TRISD3 = 1; } while(0)
#define ANA_3_SetDigitalOutput()   do { TRISDbits.TRISD3 = 0; } while(0)
#define ANA_3_SetAnalogMode()      do { ANSELDbits.ANSD3 = 1; } while(0)
#define ANA_3_SetDigitalMode()     do { ANSELDbits.ANSD3 = 0; } while(0)

// get/set ANA_4 aliases
#define ANA_4_TRIS                 TRISDbits.TRISD4
#define ANA_4_LAT                  LATDbits.LATD4
#define ANA_4_PORT                 PORTDbits.RD4
#define ANA_4_ANS                  ANSELDbits.ANSD4
#define ANA_4_SetHigh()            do { LATDbits.LATD4 = 1; } while(0)
#define ANA_4_SetLow()             do { LATDbits.LATD4 = 0; } while(0)
#define ANA_4_Toggle()             do { LATDbits.LATD4 = ~LATDbits.LATD4; } while(0)
#define ANA_4_GetValue()           PORTDbits.RD4
#define ANA_4_SetDigitalInput()    do { TRISDbits.TRISD4 = 1; } while(0)
#define ANA_4_SetDigitalOutput()   do { TRISDbits.TRISD4 = 0; } while(0)
#define ANA_4_SetAnalogMode()      do { ANSELDbits.ANSD4 = 1; } while(0)
#define ANA_4_SetDigitalMode()     do { ANSELDbits.ANSD4 = 0; } while(0)

// get/set ANA_5 aliases
#define ANA_5_TRIS                 TRISDbits.TRISD5
#define ANA_5_LAT                  LATDbits.LATD5
#define ANA_5_PORT                 PORTDbits.RD5
#define ANA_5_ANS                  ANSELDbits.ANSD5
#define ANA_5_SetHigh()            do { LATDbits.LATD5 = 1; } while(0)
#define ANA_5_SetLow()             do { LATDbits.LATD5 = 0; } while(0)
#define ANA_5_Toggle()             do { LATDbits.LATD5 = ~LATDbits.LATD5; } while(0)
#define ANA_5_GetValue()           PORTDbits.RD5
#define ANA_5_SetDigitalInput()    do { TRISDbits.TRISD5 = 1; } while(0)
#define ANA_5_SetDigitalOutput()   do { TRISDbits.TRISD5 = 0; } while(0)
#define ANA_5_SetAnalogMode()      do { ANSELDbits.ANSD5 = 1; } while(0)
#define ANA_5_SetDigitalMode()     do { ANSELDbits.ANSD5 = 0; } while(0)

// get/set ANA_6 aliases
#define ANA_6_TRIS                 TRISDbits.TRISD6
#define ANA_6_LAT                  LATDbits.LATD6
#define ANA_6_PORT                 PORTDbits.RD6
#define ANA_6_ANS                  ANSELDbits.ANSD6
#define ANA_6_SetHigh()            do { LATDbits.LATD6 = 1; } while(0)
#define ANA_6_SetLow()             do { LATDbits.LATD6 = 0; } while(0)
#define ANA_6_Toggle()             do { LATDbits.LATD6 = ~LATDbits.LATD6; } while(0)
#define ANA_6_GetValue()           PORTDbits.RD6
#define ANA_6_SetDigitalInput()    do { TRISDbits.TRISD6 = 1; } while(0)
#define ANA_6_SetDigitalOutput()   do { TRISDbits.TRISD6 = 0; } while(0)
#define ANA_6_SetAnalogMode()      do { ANSELDbits.ANSD6 = 1; } while(0)
#define ANA_6_SetDigitalMode()     do { ANSELDbits.ANSD6 = 0; } while(0)

// get/set ANA_7 aliases
#define ANA_7_TRIS                 TRISDbits.TRISD7
#define ANA_7_LAT                  LATDbits.LATD7
#define ANA_7_PORT                 PORTDbits.RD7
#define ANA_7_ANS                  ANSELDbits.ANSD7
#define ANA_7_SetHigh()            do { LATDbits.LATD7 = 1; } while(0)
#define ANA_7_SetLow()             do { LATDbits.LATD7 = 0; } while(0)
#define ANA_7_Toggle()             do { LATDbits.LATD7 = ~LATDbits.LATD7; } while(0)
#define ANA_7_GetValue()           PORTDbits.RD7
#define ANA_7_SetDigitalInput()    do { TRISDbits.TRISD7 = 1; } while(0)
#define ANA_7_SetDigitalOutput()   do { TRISDbits.TRISD7 = 0; } while(0)
#define ANA_7_SetAnalogMode()      do { ANSELDbits.ANSD7 = 1; } while(0)
#define ANA_7_SetDigitalMode()     do { ANSELDbits.ANSD7 = 0; } while(0)

// get/set WIZ_RES aliases
#define WIZ_RES_TRIS                 TRISEbits.TRISE0
#define WIZ_RES_LAT                  LATEbits.LATE0
#define WIZ_RES_PORT                 PORTEbits.RE0
#define WIZ_RES_ANS                  ANSELEbits.ANSE0
#define WIZ_RES_SetHigh()            do { LATEbits.LATE0 = 1; } while(0)
#define WIZ_RES_SetLow()             do { LATEbits.LATE0 = 0; } while(0)
#define WIZ_RES_Toggle()             do { LATEbits.LATE0 = ~LATEbits.LATE0; } while(0)
#define WIZ_RES_GetValue()           PORTEbits.RE0
#define WIZ_RES_SetDigitalInput()    do { TRISEbits.TRISE0 = 1; } while(0)
#define WIZ_RES_SetDigitalOutput()   do { TRISEbits.TRISE0 = 0; } while(0)
#define WIZ_RES_SetAnalogMode()      do { ANSELEbits.ANSE0 = 1; } while(0)
#define WIZ_RES_SetDigitalMode()     do { ANSELEbits.ANSE0 = 0; } while(0)

// get/set CONF aliases
#define CONF_TRIS                 TRISEbits.TRISE1
#define CONF_LAT                  LATEbits.LATE1
#define CONF_PORT                 PORTEbits.RE1
#define CONF_ANS                  ANSELEbits.ANSE1
#define CONF_SetHigh()            do { LATEbits.LATE1 = 1; } while(0)
#define CONF_SetLow()             do { LATEbits.LATE1 = 0; } while(0)
#define CONF_Toggle()             do { LATEbits.LATE1 = ~LATEbits.LATE1; } while(0)
#define CONF_GetValue()           PORTEbits.RE1
#define CONF_SetDigitalInput()    do { TRISEbits.TRISE1 = 1; } while(0)
#define CONF_SetDigitalOutput()   do { TRISEbits.TRISE1 = 0; } while(0)
#define CONF_SetAnalogMode()      do { ANSELEbits.ANSE1 = 1; } while(0)
#define CONF_SetDigitalMode()     do { ANSELEbits.ANSE1 = 0; } while(0)

// get/set THRU aliases
#define THRU_TRIS                 TRISEbits.TRISE2
#define THRU_LAT                  LATEbits.LATE2
#define THRU_PORT                 PORTEbits.RE2
#define THRU_ANS                  ANSELEbits.ANSE2
#define THRU_SetHigh()            do { LATEbits.LATE2 = 1; } while(0)
#define THRU_SetLow()             do { LATEbits.LATE2 = 0; } while(0)
#define THRU_Toggle()             do { LATEbits.LATE2 = ~LATEbits.LATE2; } while(0)
#define THRU_GetValue()           PORTEbits.RE2
#define THRU_SetDigitalInput()    do { TRISEbits.TRISE2 = 1; } while(0)
#define THRU_SetDigitalOutput()   do { TRISEbits.TRISE2 = 0; } while(0)
#define THRU_SetAnalogMode()      do { ANSELEbits.ANSE2 = 1; } while(0)
#define THRU_SetDigitalMode()     do { ANSELEbits.ANSE2 = 0; } while(0)

/**
   @Param
    none
   @Returns
    none
   @Description
    GPIO and peripheral I/O initialization
   @Example
    PIN_MANAGER_Initialize();
 */
void PIN_MANAGER_Initialize (void);

/**
 * @Param
    none
 * @Returns
    none
 * @Description
    Interrupt on Change Handling routine
 * @Example
    PIN_MANAGER_IOC();
 */
void PIN_MANAGER_IOC(void);



#endif // PIN_MANAGER_H
/**
 End of File
*/