/*---------------------------------------------------------------------------
	Project:	      PUTSI WiFi

	Module:		      Utility routines

	File Name:	      utils.c

	Author:		      Martin C. Alcock, VE6VH

	Revision:	      1.0

	Description:      Mainline for PIC application

            		  Copyright (c) 2018-2022 Praebius Communications Inc.

	Revision History:

---------------------------------------------------------------------------*/
#include "putsi.h"

// convert an ascii string to a uint8
uint8_t A2_uint8_t(char *s)
{
    uint8_t val = 0, newval;
    
    while(*s)   {
        newval = (uint8_t)(val << 3);              //*8      
        newval += val << 1;             //*2 + *8  = *10
        val = newval + (*s++ - '0');    // *10 + new value
    }
    return val;
}

// convert an ascii string to a uint16
uint16_t A2_uint16_t(char *s)
{
    uint16_t val = 0, newval;
    
    while(*s)   {
        newval = val << 3;              //*8      
        newval += val << 1;             //*2 + *8  = *10
        val = newval + (*s++ - '0');    // *10 + new value
    }
    return val;
}

// convert an ascii string to a uint32
// same code, wider int
uint32_t A2_uint32_t(char *s)
{
    uint32_t val = 0, newval;
    
    while(*s)   {
        newval = val << 3;              //*8      
        newval += val << 1;             //*2 + *8  = *10
        val = newval + (*s++ - '0');    // *10 + new value
    }
    return val;
}
            