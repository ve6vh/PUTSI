/*---------------------------------------------------------------------------
	Project:	      DAQ imlementation for Allstar

	Module:		      Transmit Message Handler

	File Name:	      daqMsgTx.c

	Author:		      Martin C. Alcock, VE6VH

	Revision:	      1.05

	Description:      Mainline for DAQ serial monitor

					This program is free software: you can redistribute it and/or modify
					it under the terms of the GNU General Public License as published by
					the Free Software Foundation, either version 2 of the License, or
					(at your option) any later version, provided this copyright notice
					is included.

					Copyright (c) 2018-2022 Praebius Communications Inc.

	Revision History:

---------------------------------------------------------------------------*/
#include <stdio.h>

#include "putsi.h"
#include "usb.h"

// debug
#define     NO_DEF_MSG          0       // do not send default msg

#define     STACK_LIM           8		// sizeof (stack)
#define     COUNTER_RELOAD      120     // 15 ms between ints

uint16_t    txCounter;                  // tx counter
uint16_t    USBreportCounter;
BOOL        USBreportTime=FALSE;

// message stack
STACK_ELEMENT msg_stack[STACK_LIM];
uint8_t msg_stack_ptr = 0;

BOOL enqueBusy = FALSE;

STACK_ELEMENT null_msg = { .item = MK_ELEMENT(MSG_NOMSG, INT_NULL) };
STACK_ELEMENT def_msg = { .item = MK_ELEMENT(MSG_INT, INT_NULL) };

// internal messages
char *int_msgs[N_INT] = {
	"ok\n",
	"dev Chameleon\n"
};

// pin state to values
int pinState2Value[] = {
	0,			// OFF
	0,			// Low
	1,			// High
};

char msgBuf[16];			// message buffer
DAQ_THREADS     *defs;      // definitions, etc

// internals
STACK_ELEMENT DeQueMsg(void);
void int2asc(char *buffer, uint8_t value);

void startDAQTx(DAQ_THREADS *sys_defs)
{
    defs = sys_defs;
    defs->txReady = FALSE;
    msg_stack_ptr = 0;   
    USBreportCounter = COUNTER_RELOAD;
}

// reset the machines
void stopDAQTx(void)
{
    if(!defs->txReady)
        return;
    
    // turn off the led and txReady
    COMLed_SetUSBStatus(FALSE);
    defs->txReady = FALSE;
    msg_stack_ptr = 0;   
    USBreportCounter = COUNTER_RELOAD;
    USBreportTime=FALSE;    
    
    IO_Task_Start();
}

// timer runs in quanta of 100 usec
void USB_Timer(void)
{
    if(USBreportCounter > 0)  {
        USBreportCounter--;
        return;
    }

    USBreportCounter = COUNTER_RELOAD;
    USBreportTime=TRUE;
}

// get/reset the report timer
BOOL USB_Get_Timer(void)
{
    if(!USBreportTime)
        return FALSE;
    
    // reset for next time...
    USBreportTime=FALSE;
    return TRUE;
}

// test to see if constant tx is enabled
BOOL isUSBTxEnabled(void)
{
    return defs->txReady;
}

void DAQMsgTx(void)
{
	STACK_ELEMENT deque_msg;
    uint8_t *msg; 
    uint8_t len;
    uint8_t pinNum;

	// get a message from the stack
	deque_msg = DeQueMsg();

    uint8_t msg_type = ELEMENT_TYPE(deque_msg);
    
	// form the return message
	switch (msg_type) {

	case MSG_NOMSG:
		return;

	case MSG_INT:
		// internal message
		msg = (uint8_t *)int_msgs[ELEMENT_MSGNUM(deque_msg)];
        len = (uint8_t)strlen(int_msgs[ELEMENT_MSGNUM(deque_msg)]);
        mUSBUSARTTxRam(msg, len);
		break;

	case MSG_PIN:
		// pin message
        pinNum = ELEMENT_MSGNUM(deque_msg);
		strcpy(msgBuf, "pin ");
		int2asc(&msgBuf[4], TOPINNUM(pinNum));
        if(defs->ioData->digIn_data[pinNum].STATE > 0)
			strcat(msgBuf, " 1\n");
		else
			strcat(msgBuf, " 0\n");
		msg = (uint8_t *)msgBuf;
        len = (uint8_t)strlen(msgBuf);
        mUSBUSARTTxRam(msg, len);        
		break;
        
    case MSG_ADC:
        // adc request
        StartPollTimer();        
        pinNum = ELEMENT_MSGNUM(deque_msg);
        strcpy(msgBuf, "adc ");
        int2asc(&msgBuf[4], pinNum);
        strcat(msgBuf," ");
        int2asc(&msgBuf[6],ADC_Get8BitValue(pinNum));
        strcat(msgBuf, "\n");
		msg = (uint8_t *)msgBuf;
        len = (uint8_t)strlen(msgBuf);
        mUSBUSARTTxRam(msg, len);                
        break;
            
	}
	return;
}

// enque a message 
// called to send out a message also by timer isr
BOOL EnQueMsg(STACK_ELEMENT item, uint8_t txstat)
{
    enqueBusy = TRUE;
    BOOL retval = TRUE;

    if (msg_stack_ptr < STACK_LIM) {
        msg_stack[msg_stack_ptr++] = item;
        switch(txstat) {

            case TX_NOCHANGE:
            break;

            case TX_ON:
                // COMLed_SetUSBStatus(TRUE);
                defs->txReady = TRUE;
            break;

            case TX_OFF:
                COMLed_SetUSBStatus(FALSE);
                defs->txReady = FALSE;
            break;
        }
    } else retval = FALSE;

    enqueBusy = FALSE;
    return retval;
}


// deque a message
// if stack is empty; repeat the last message
STACK_ELEMENT DeQueMsg(void) 
{
	STACK_ELEMENT retval;

    // wait for interrupt code to complete..
    while(enqueBusy);
    
	// if stack is empty, send out a NULL message
	if (msg_stack_ptr == 0) {
		if (defs->txReady)
#if NO_DEF_MSG
            return(null_msg);            
#else            
			return(def_msg);
#endif        
	}
	else {
        msg_stack_ptr -= 1;
		retval = msg_stack[msg_stack_ptr];
        return retval;
    }
    return(null_msg);
}

// convert a byte to an ascii string
void int2asc(char *buffer, uint8_t value)
{
	uint8_t baseval = 100;
	uint8_t lzsuppress = TRUE;

	while (baseval) {
		uint8_t digit = (value / baseval);
		value -= digit * baseval;
		baseval /= 10;
		// only put out digits if non-zero
		if (digit)
			lzsuppress = FALSE;
		if(!lzsuppress)
			*buffer++ = digit + '0';
	}

	// nothing emitted; value must be zero
	if (lzsuppress)
		*buffer++ = '0';
	*buffer = '\0';
}
