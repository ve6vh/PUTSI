/*---------------------------------------------------------------------------
	Project:	      DAQ imlementation for Allstar

	Module:		      Buffer an rx message into a string..

	File Name:	      daqMsgRx.c

	Author:		      Martin C. Alcock, VE6VH

	Revision:	      1.05

	Description:      remove characters from buffer to form a complete message

					This program is free software: you can redistribute it and/or modify
					it under the terms of the GNU General Public License as published by
					the Free Software Foundation, either version 2 of the License, or
					(at your option) any later version, provided this copyright notice
					is included.

					Copyright (c) 2018-2022 Praebius Communications Inc.

	Revision History:

---------------------------------------------------------------------------*/
#include <stdint.h>
#include <stdio.h>

#include "putsi.h"
#include "usb.h"

// Receiver States
#define		IDLE		0			// idle: looking for data
#define		DATA		1			// data message coming in...

// macros
#define	NIB2ASC(c)	(c>9) ? (c + '0' + 7) : (c + '0');

DAQ_THREADS daq_threads;
DATA_ELEMENT *rxBuf;
DATA_ELEMENT localbuf[SMALLbuffer];

// start the background rx
BOOL InitUSBMode(IO_DATA *iodata)
{
    DAQ_THREADS *t = &daq_threads;
    t->msgLen = 0;
	t->rxstate = IDLE;
    t->ioData = iodata;
    t->msgBuffer = localbuf;
	rxBuf = t->msgBuffer;
    
    startDAQTx(&daq_threads);
    
	return TRUE;
}

// finish the current buffer
void stopDAQRx(void)
{
}

// foreground rx: processing at the message level
void DAQMsgRx(void)
{
	DAQ_THREADS *t = &daq_threads;
	DATA_ELEMENT c;

	switch (t->rxstate) {

		// no data yet
		case IDLE:
			if((c = databuffer_get_small(&usb_rxBuffer)) == BUFFER_NO_DATA)
                return;
			t->msgLen = 1;
			*rxBuf++ = c;
			t->rxstate = DATA;
		break;

		// receiving message
		case DATA:
			if((c = databuffer_get_small(&usb_rxBuffer)) == BUFFER_NO_DATA)
                return;
			if (c == '\n') {
				t->rxstate = IDLE;
				*rxBuf = '\0';
				daqMsgProc(t);
				rxBuf = t->msgBuffer;
			}
			else {
				*rxBuf++ = c;
				t->msgLen++;
			}
		break;
	}
}

