/*---------------------------------------------------------------------------
	Project:	      PUTSI WiFi

	File Name:	      comLED.c

	Author:		      Martin C. Alcock, VE6VH

	Revision:	      0.02

	Description:      Header file for PUTSI project

                      This software module and all others are the exclusive property of the Alberta Digital 
                      Radio Communications Society and others (?the owners?), all rights are reserved.

                      The owners grant licence to any Amateur for personal or club use, and only on hardware
                      designed by them expressly for this purpose, use on any other hardware is prohibited.
 
                      This file, and others may be copied or distributed only with the inclusion of this 
                      notice.

                      No warranty, either express or implied or transfer of rights is granted in this 
                      licence and the owner is not liable for any outcome whatsoever arising from such usage.

                      Copyright � 2023, Alberta Digital Radio Communications Society


	Revision History:

---------------------------------------------------------------------------*/
#include "mcc_generated_files/mcc.h"
#include "putsi.h"

#define BI_DIR_LED          1           // bi directional LED

#define LED_OFF             0           // led is off
#define LED_ON              1           // led is on
#define LED_FORWARD         0           // forward bias
#define LED_REVERSE         1           // reverse bias

BOOL ToggleEnable;
uint8_t ledMode;                        // led mode
uint8_t ledDirection;                   // direction (colour)
uint8_t ledState;                       // state on/off

// status
BOOL    WifiConnected = FALSE;
BOOL    USBLed = FALSE;

// internals
void COMLedSetState(void);
void COMLed_setMode(uint8_t mode);
void LED_SetOff(void);
void LED_SetFwd(void);
void LED_SetRev(void);

// init: turn it off
void COMLed_init(void)
{
    ledMode = LED_OFF;
    ToggleEnable = FALSE;
    ledDirection = LED_FORWARD;
    
    WifiConnected = FALSE;
    USBLed = FALSE;
    COMLedSetState();
}

// set in configuration mode
void COMLed_SetConfigStatus(bool config)
{
    if(config)
        COMLed_setMode(LED_RED_FLASH);
    else
        COMLed_setMode(LED_OFF);
}

// set wifi status
void COMLed_SetWifiStatus(bool connected)
{
    WifiConnected = connected;
    COMLedSetState();
}

// set USB status
void COMLed_SetUSBStatus(bool ledstate)
{
    USBLed = ledstate;
    COMLedSetState();
}

// set the current state
void COMLedSetState(void)
{
    uint8_t state = (uint8_t)(USBLed <<1) | WifiConnected;
    
    switch (state)  {
        
        case 0:             // both off
            COMLed_setMode(LED_OFF);
            break;
            
        case 1:             // Wifi Only
            COMLed_setMode(LED_RED);
            break;
            
        case 2:             // USB only
            COMLed_setMode(LED_GREEN);
            break;
            
        case 3:             // USB & Wifi
            COMLed_setMode(LED_RED_GREEN);
            break;
            
    }
}

void COMLed_setMode(uint8_t mode)
{
    ledMode = mode;
    
    switch(mode)    {

        case LED_OFF:
            LED_SetOff();
            ToggleEnable = FALSE;
            ledState = LED_OFF;
            break;
            
        case LED_RED:
            LED_SetFwd();
            ToggleEnable = FALSE;
            ledDirection = LED_FORWARD;            
            ledState = LED_ON;
            break;
            
        case LED_RED_FLASH:
            LED_SetFwd();
            ToggleEnable = TRUE;
            ledDirection = LED_FORWARD;
            ledState = LED_ON;
            break;            

        case LED_GREEN:
            LED_SetRev();
            ToggleEnable = FALSE;
            ledDirection = LED_REVERSE;            
            ledState = LED_ON;
            break;
            
        case LED_GREEN_FLASH:
            LED_SetRev();
            ToggleEnable = TRUE;
            ledDirection = LED_REVERSE;            
            ledState = LED_ON;
            break;

        case LED_RED_GREEN:
            LED_SetOff();
            ToggleEnable = TRUE;
            ledDirection = LED_FORWARD;
            ledState = LED_ON;
            break;
            
    }
}


// timer interrupt: toggle if in config or thru mode
void COMLed_timer(void)
{
    // blink LED if enabled
    if(ToggleEnable)    {
        
        switch(ledMode)        {
            
            case LED_RED_FLASH:
            case LED_GREEN_FLASH:                
                ledState = (ledState == LED_ON) ? LED_OFF : LED_ON;
                break;
                
            case LED_RED_GREEN:
                ledDirection = (ledDirection == LED_FORWARD) ? LED_REVERSE : LED_FORWARD;
                break;
                        
            default:
                return;
        }
        
        // update the LED state
        if(ledState == LED_OFF)
            LED_SetOff();
        else {
            if(ledDirection == LED_FORWARD)
                LED_SetFwd();
            else
                LED_SetRev();
        }
    }
}

// do the actual updates
void LED_SetOff(void)
{
    COM_CATH_SetLow();
    COM_ANODE_SetLow();
    COM_SetLow();
}

// set fwd direction for bidir LED
// set single LED on
void LED_SetFwd(void)
{
#if BI_DIR_LED
    COM_CATH_SetLow();
    COM_ANODE_SetHigh();
#else
    COM_SetHigh();
#endif        
}

// set bwd direction for bidir LED
// set single LED on
void LED_SetRev(void)
{
#if BI_DIR_LED
    COM_CATH_SetHigh();
    COM_ANODE_SetLow();
#else
    COM_SetHigh();
#endif        
}


