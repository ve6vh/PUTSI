/*---------------------------------------------------------------------------
	Project:	      PUTSI WiFi

	Module:		      ADC Task

	File Name:	      adcTask.c

	Revision:	      0.02

	Description:      Header file for PUTSI project

                      This software module and all others are the exclusive property of the Alberta Digital 
                      Radio Communications Society and others (?the owners?), all rights are reserved.

                      The owners grant licence to any Amateur for personal or club use, and only on hardware
                      designed by them expressly for this purpose, use on any other hardware is prohibited.
 
                      This file, and others may be copied or distributed only with the inclusion of this 
                      notice.

                      No warranty, either express or implied or transfer of rights is granted in this 
                      licence and the owner is not liable for any outcome whatsoever arising from such usage.

                      Copyright � 2023, Alberta Digital Radio Communications Society


	Revision History:

---------------------------------------------------------------------------*/
#include "adc.h"
#include "putsi.h"

#define     USE_INTERRUPT           1               // use interrupt

BOOL    ADC_Done;

// A/D Input channels
adc_channel_t ADC_Channels[N_ADC] = {
    ANA_0,    ANA_1,    ANA_2,   ANA_3,
    ANA_4,    ANA_5,    ANA_6,   ANA_7
};

uint8_t CurrADC_idx;

// internals
void Start_conv(void);
void ADC_StartConversion(void);

void ADC_Task_Start(void)   
{
    CurrADC_idx = 0;
    Start_conv();
}

// update to next...
void ADC_Conv_Update(IO_DATA *io_data)
{
#if USE_INTERRUPT
    if(!ADC_Done)
        return;
#else    
    if(!ADC_IsConversionDone())
        return;
#endif    
    
    // update the current value
    ADC_WORD newConv = ADC_GetConversion(ADC_Channels[CurrADC_idx]);
    io_data->adc_data[CurrADC_idx].value = newConv;    
    if(newConv != io_data->adc_data[CurrADC_idx].value) {
        io_data->adc_data[CurrADC_idx].CHANGED = PIN_STATE_CHANGED;
    } else {
        io_data->adc_data[CurrADC_idx].CHANGED = PIN_STATE_NOCHANGE;        
    }

    // continue
    CurrADC_idx = NEXTADC(CurrADC_idx);
    Start_conv();
}

// start a new conversion
void Start_conv(void)
{
    ADC_Done = FALSE;
    ADC_SelectChannel(ADC_Channels[CurrADC_idx]);
    ADC_StartConversion();
}

// completion interrupt
void ADC_Interrupt(void)
{
    ADC_Done = TRUE;
}

// ADC is 10 bits, so reduce to 8 for Allstar
uint8_t ADC_Get8BitValue(uint8_t pin)
{
    IO_DATA *io_data = Get_IO_Data();
    uint8_t pinNum = PIN_TO_ADDR(pin);
    
    uint8_t pinValue = (uint8_t)(io_data->adc_data[pinNum].value>>2);
    return (pinValue);
}
