/*******************************************************************
 * 
 * Project:     PIC based Data Aqcuisition system for Allstar
 * 
 * Module:      USB Rx Handler
 * 
 * FileName:    usb_rx.c
 * 
 * Decription:  Handle reception of the USB characters and put them
 *              into the rx buffer
 *
 * Author:      Martin C. Alcock, M.Sc, VE6VH 
 
 *******************************************************************/
#include <stdint.h>
#include "usb.h"
#include "putsi.h"

// receive buffer for USB
SMALLBUFFER usb_rxBuffer;

// local buffers
static DATA_ELEMENT readBuffer[64];

void USB_Rx(void)
{
    if( USBGetDeviceState() < CONFIGURED_STATE )
    {
        return;
    }

    if( USBIsDeviceSuspended()== true )
    {
        return;
    }

   if( USBUSARTIsTxTrfReady() == true)
    {
        uint8_t i;
        uint8_t numBytesRead;

        numBytesRead = getsUSBUSART(readBuffer, sizeof(readBuffer));

        if(numBytesRead > 0)
        {
            for(i=0; i<numBytesRead; i++)
            {
                databuffer_put_small(readBuffer[i], &usb_rxBuffer);
            }
        }
    }

}
