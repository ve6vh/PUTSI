/*---------------------------------------------------------------------------
	Project:	      PUTSI WiFi

	Module:           Setup data

	File Name:	      Setup.c

	Author:		      Martin C. Alcock, VE6VH

	Revision:	      1.0

	Description:      Mainline for PIC application

            		  Copyright (c) 2018-2022 Praebius Communications Inc.

	Revision History:

---------------------------------------------------------------------------*/

#include <string.h>
#include <pic18.h>

#include "putsi.h"

// default setup data
SETUP_DATA def_setup = {
    "169.34.100.2",
    "44001",
    "45001",
    "3276345",
    "30",
    "MyAP",
    "Passwd",
    FALSE, 
    TRUE,
    FALSE,
    SETUP_MAGIC
};

union {
    SETUP_DATA  setup_data;              // working copy
    uint8_t     EEData[sizeof(SETUP_DATA)];
} setup_memory;

// internals
void DATAEE_WriteByte(uint8_t bAdd, uint8_t bData);
uint8_t DATAEE_ReadByte(uint8_t bAdd);
BOOL read_setup(void);

// retreive the setup data from the flash
BOOL init_setup(void)
{

    // first read it and see if it is valid
    if(read_setup())
        return TRUE;

    // use the default values: initialize the EEPROM
    memcpy((void *)&setup_memory.setup_data, (const void *)&def_setup, sizeof(SETUP_DATA));
    Write_Setup();
    
    // now read again and check 
    if(read_setup())
        return TRUE;
    
    return FALSE;
}

BOOL read_setup(void)
{
    uint8_t setupSize = sizeof(SETUP_DATA);
    uint8_t EEAddr = 0;
    
    for(int i=0;i<setupSize;i++)        {
            uint8_t EEByte = DATAEE_ReadByte(EEAddr++);
            setup_memory.EEData[i] = EEByte;
    }
    
    // if the magic number matches, then all is well
    if(setup_memory.setup_data.Magic == SETUP_MAGIC)
        return TRUE;
    
    // memory is not valid
    return FALSE;
}

// write setup to flash: TODO
void Write_Setup(void)
{
    
    uint8_t EEAddr = 0;
    uint8_t *EEWrBufPtr = &setup_memory.EEData[0];
    uint8_t nEEWrite = sizeof(SETUP_DATA);

    for(uint8_t i=0; i<nEEWrite;i++)    {
        uint8_t EEData = *EEWrBufPtr;
        DATAEE_WriteByte(EEAddr, EEData);
        EEAddr++;
        EEWrBufPtr++;
    }
    return;
}

SETUP_DATA *Get_Setup(void)
{
    return &setup_memory.setup_data;
}


// check wifi and usb modes
BOOL isWifiEnabled(void)
{
    return setup_memory.setup_data.flags.WiFiEnabled;
}

BOOL isUSBEnabled(void)
{
    return setup_memory.setup_data.flags.USBEnabled;
}

BOOL isAutoConfigEnabled(void)
{
    return setup_memory.setup_data.flags.AutoConfig;
}

/**
  Section: Data EEPROM Module APIs
*/
void DATAEE_WriteByte(uint8_t bAdd, uint8_t bData)
{
    uint8_t GIEBitValue = INTCONbits.GIE;

    EEADR = (uint8_t)(bAdd & 0xFF);
    EEDATA = bData;
    EECON1bits.EEPGD = 0;
    EECON1bits.CFGS = 0;
    EECON1bits.WREN = 1;
    INTCONbits.GIE = 0;     // Disable interrupts
    EECON2 = 0x55;
    EECON2 = 0xAA;
    EECON1bits.WR = 1;
    // Wait for write to complete
    while (EECON1bits.WR)
    {
    }

    EECON1bits.WREN = 0;
    INTCONbits.GIE = GIEBitValue;   // Restore interrupt enable
}

uint8_t DATAEE_ReadByte(uint8_t bAdd)
{
    EEADR = (uint8_t)(bAdd & 0xFF);
    EECON1bits.CFGS = 0;
    EECON1bits.EEPGD = 0;
    EECON1bits.RD = 1;
    NOP();  // NOPs may be required for latency at high frequencies
    NOP();

    return (EEDATA);
}