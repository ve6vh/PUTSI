/*---------------------------------------------------------------------------
	Project:	      PUTSI WiFi

	Module:		      USRP Handler

	File Name:	      usrp.c

	Author:		      Martin C. Alcock, VE6VH

	Revision:	      1.0

	Description:      Mainline for PIC application

            		  Copyright (c) 2018-2022 Praebius Communications Inc.

	Revision History:

---------------------------------------------------------------------------*/
#include <stdio.h>
#include <string.h>

#include "putsi.h"

#define USE_SSCANF     0            // save memory by not using sscanf


uint16_t    reportInterval;
uint16_t    reportCounter;
BOOL        reportTime=FALSE;
BOOL        responseExpected=FALSE;

uint32_t    radioID;
uint32_t    txCnt=0;

// Telemetry packet
UDP_TELEMETRY_PACKET udp_telemetry_packet;
UDP_RESPONSE_PACKET UDP_response_pkt;

typedef union {
    uint32_t     lword;
    uint8_t      bytes[4];
} LONG2BYTES;

//  internals
void inttobuf(uint32_t value, uint8_t *fld, uint8_t len);
uint32_t htonl(uint32_t in);

// init the USRP UDP mode
BOOL USRP_Init(void)
{
    SETUP_DATA *setup_params;
    setup_params = Get_Setup();
    BOOL stat;

    // get  setup data in ints
#if USE_SSCANF    
    sscanf(setup_params->Interval,"%hd", &reportInterval);
    sscanf(setup_params->RadioID,"%ld",&radioID);
#else
    reportInterval = A2_uint16_t(setup_params->Interval);
    radioID = A2_uint32_t(setup_params->RadioID);
#endif    
    
    reportCounter = reportInterval;

    // attempt to connect to AP
    stat=WizFi_APConnect(setup_params->NetName, setup_params->NetPwd);
   
    return stat;
}

BOOL USRP_Start(void)
{
    SETUP_DATA *setup_params = Get_Setup();
    BOOL stat;
    
    stat=Wizfi_UDPSetup(setup_params->IPAddress, setup_params->SvrPort, setup_params->LclPort);

    return stat;
}

// count down the time to report
void USRP_Timer(void)
{
    if(reportCounter > 0)  {
        reportCounter--;
        return;
    }

    reportCounter = reportInterval;
    reportTime=TRUE;
}

// get/reset the report timer
BOOL USRP_Get_Timer(void)
{
    if(!reportTime)
        return FALSE;
    
    // reset for next time...
    reportTime=FALSE;
    return TRUE;
}

void USRP_SendPacket(IO_DATA *p)
{
    SETUP_DATA *setup_data = Get_Setup();

	// create the header: ensure that keyup is clear for a non-audio packet
	strcpy((char *)udp_telemetry_packet.hdr.eye, "USRP");
	udp_telemetry_packet.hdr.seq = htonl(txCnt++);
	udp_telemetry_packet.hdr.keyup =  0;
	udp_telemetry_packet.hdr.type = USRP_TYPE_TLV;

	// header fields
	udp_telemetry_packet.tlv.type = (uint8_t)TLV_TAG_TELEMETRY;
	udp_telemetry_packet.tlv.length = (uint8_t)sizeof(TLV_TELEMETRY_PACKET);
	uint8_t *usrp_data = udp_telemetry_packet.radioID;
	inttobuf(radioID, usrp_data, sizeof(long));
    
    // A/D Data first
    udp_telemetry_packet.packet.ADCHeader.type =  (uint8_t)TELEM_TLV_SUB_ANALOG;
    udp_telemetry_packet.packet.ADCHeader.length = (uint8_t)N_ADC;
    usrp_data = (uint8_t *)udp_telemetry_packet.packet.adc_data;
    for(int i=0;i<(uint8_t)N_ADC;i++)	{
		inttobuf(p->adc_data[i].value, usrp_data, sizeof(ADC_WORD));
		usrp_data += sizeof(uint16_t);
	}
    
    // then digital inputs
    udp_telemetry_packet.packet.DigInHeader.type =  (uint8_t)TELEM_TLV_SUB_DIGIN;
    udp_telemetry_packet.packet.DigInHeader.length = (uint8_t)N_INPUTS;
    usrp_data = (uint8_t *)udp_telemetry_packet.packet.digIn_data;
    
	for(int i=0;i<N_INPUTS;i++)
        *usrp_data++ = (uint8_t)p->digIn_data[i].BYTE&PIN_STATE_ON;

    // next digital outputs
    udp_telemetry_packet.packet.DigOutHeader.type =  (uint8_t)TELEM_TLV_SUB_DIGOUT;
	udp_telemetry_packet.packet.DigOutHeader.length = (uint8_t)N_OUTPUTS;
	usrp_data = (uint8_t *)udp_telemetry_packet.packet.digOut_data;
    
	for(int i=0;i<(uint8_t)N_OUTPUTS;i++)
		*usrp_data++ = p->digOut_data[i].BYTE&PIN_STATE_ON;

	// send it out...
	size_t bufsize = sizeof(UDP_TELEMETRY_PACKET);
    Wizfi_Send_UDPData(bufsize, setup_data->IPAddress, setup_data->SvrPort);
    WizFi_Send_Uint8((uint8_t *)&udp_telemetry_packet, bufsize, DUPLEX_DELAY);
    
    responseExpected = TRUE;
}

// check if we have an inbound packet
BOOL USRP_hasRxPacket(void)
{
    // no response pending...
    if(!responseExpected)
        return FALSE;
    
    return WizFi_hasPacket("USRP");
}

// process an inbound packet
void USRP_GetPacket(IO_DATA *p)
{
    BOOL stat=FALSE;
    
    // retreive the packet
    uint8_t *p_UDP = UDP_response_pkt.packet;
    p_UDP += EYE_SIZE + 1;
    stat=WizFi_getPacket(p_UDP, sizeof(UDP_RESPONSE)-EYE_SIZE-1, REQ_TIMEOUT);
    
   if(!stat)
        return;
    
    uint8_t n_out = UDP_response_pkt.response.packet.DigOutHeader.length;
    IO_DATA *iodata = Get_IO_Data();
    
    for(uint8_t i=0;i<n_out;i++)    {
        if(iodata->digOut_data[i].STATE != (UDP_response_pkt.response.packet.digOut_data[i]&PIN_STATE_ON))  {
            iodata->digOut_data[i].STATE = UDP_response_pkt.response.packet.digOut_data[i]&PIN_STATE_ON;
            iodata->digOut_data[i].UPDATE = 1;
        }
    }

    responseExpected = FALSE;
    return;
}

/*
 * pack an int into the buffer
 */
void inttobuf(uint32_t value, uint8_t *fld, uint8_t len)
{
    LONG2BYTES word;
    word.lword = value;
    
    for(int i=len-1;i>=0;i--)  {
      *fld = word.bytes[i];
      fld++;
    }
}

// swap bytes in a 32-bit word
uint32_t htonl(uint32_t in)
{
    LONG2BYTES inword;
    LONG2BYTES outword;
    
    inword.lword = in;
    
    outword.bytes[0] = inword.bytes[3];
    outword.bytes[1] = inword.bytes[2];
    outword.bytes[2] = inword.bytes[1];
    outword.bytes[3] = inword.bytes[0];
    
    return outword.lword;
    
}