/*---------------------------------------------------------------------------
	Project:	      PUTSI WiFi

	Module:		      Wifi handler for WizFi360

	File Name:	      main.c

	Author:		      Martin C. Alcock, VE6VH

	Revision:	      1.0

	Description:      Mainline for PIC application

            		  Copyright (c) 2018-2022 Praebius Communications Inc.

	Revision History:

---------------------------------------------------------------------------*/
#include <stdio.h>

#include "mcc_generated_files/mcc.h"
#include "putsi.h"

// conditional compilation
#define USB_TEST       0            // USB loopback mode
#define USE_SPRINF     0            // save memory by not using sprintf
#define UDP_SEND_ADDR  0            // send address with UDP command

// decimal conversion
#define DEC_BASE       10           // decimal 
const char digits[] = "0123456789abcdef0123456789ABCDEF";

DATABUFFER wifi_rxBuffer;
uint8_t rxTimeOut = 0;
uint8_t rxTimerLock;

#define UNLOCKED    0
#define LOCKED      1

// for local echo
DATA_ELEMENT WifiUSBBuffer[64];     // buffer for USB
uint8_t usbCnt;                     // usb count
BOOL stat;                          // return status

// internals
void flush_resp(uint8_t timeout);
void WizFi_Send_Num_uint8(uint8_t num, uint8_t spacing);
void WizFi_Send_Num_sizet(size_t num, uint8_t spacing);

/*
 * Hard reset using the reset line to the part
 */
void WizFi_Reset(void)    {
    WIZ_RES_SetLow();
    delay(100);
    WIZ_RES_SetHigh();
    delay(200);
}

/*
 * Soft reset using AT command
 */
BOOL WizFi_Init(void)   {

    databuffer_reset(&wifi_rxBuffer);
    stat = TRUE;
    
    // reset the Wifi device
    if(stat)    {
        WizFi_Send_String("AT+RST\r\n", DUPLEX_DELAY);
        stat=WizFi_getResp("ready",RX_TIMEOUT);    
    }
    
    // disable command echo
    if(stat)    {
        WizFi_Send_String("ATE0\r\n", DUPLEX_DELAY);
        stat=WizFi_getResp("OK",RX_TIMEOUT);
    }
    
    return stat;
}

// setup client mode (shuts off AP)
BOOL WizFi_ClientSetup(void)
{
    databuffer_reset(&wifi_rxBuffer);
    stat=TRUE;
    
    // set mode to station
    WizFi_Send_String("AT+CWMODE_CUR=1\r\n", DUPLEX_DELAY);
    stat=WizFi_getResp("OK",RX_TIMEOUT); 
    
    return stat;
}

/*
 *  The following are all related to server mode
 */
// setup AP mode
BOOL WizFi_APSetup(void)
{
    databuffer_reset(&wifi_rxBuffer);
    stat=TRUE;
    
    // set mode to station
    WizFi_Send_String("AT+CWMODE_CUR=2\r\n", DUPLEX_DELAY);
    stat=WizFi_getResp("OK",RX_TIMEOUT);    
    
    // set up the SSID, password, channel,encryption,#conn,broadcast
    if(stat)    {
        WizFi_Send_String("AT+CWSAP_CUR=\"PUTSI Wifi\",\"\",4,0,1,0\r\n", DUPLEX_DELAY);
        stat=WizFi_getResp("OK",RX_TIMEOUT);
    }    
    
    // set CIP mux on
    if(stat)    {    
        WizFi_Send_String("AT+CIPMUX=1\r\n", DUPLEX_DELAY);
        stat=WizFi_getResp("OK",RX_TIMEOUT);
    }
    
    // now enable server mode
    if(stat)    {
        WizFi_Send_String("AT+CIPSERVER=1,80\r\n", DUPLEX_DELAY);
        stat=WizFi_getResp("OK",RX_TIMEOUT);    
    }
    return stat;
}

// get an HTML request:page name and params are in the rx buffer
BOOL WizFi_getHTMLReq(void)
{
    databuffer_reset(&wifi_rxBuffer);
    stat=TRUE;
    
    // get the request leader
    if(stat)  {
        stat=WizFi_getResp("GET /", REQ_TIMEOUT);
    }
    
    // reset buffer again to flush request leader
    databuffer_reset(&wifi_rxBuffer);
    if(stat)  {
        stat=WizFi_getResp("HTTP", RX_TIMEOUT);
        flush_resp(RX_TIMEOUT);
    }
    
    return stat;
}

// send a command to send a TCP packet
BOOL Wizfi_Send_TCPData(uint8_t linkID, size_t cmdLen)
{
#if USE_SPRINF
    char cmdBuf[32];
    sprintf(cmdBuf, "AT+CIPSENDEX=%d,%u\r\n", linkID, cmdLen);
    WizFi_Send_String(cmdBuf, DUPLEX_DELAY);" 
#else    
    WizFi_Send_String("AT+CIPSENDEX=", DUPLEX_DELAY);
    WizFi_Send_Num_uint8(linkID, DUPLEX_DELAY);
    WizFi_Send_String(",", DUPLEX_DELAY);    
    WizFi_Send_Num_sizet(cmdLen, DUPLEX_DELAY);
    WizFi_Send_String("\r\n", DUPLEX_DELAY);
#endif    
    
    databuffer_reset(&wifi_rxBuffer);
    stat=WizFi_getResp("OK",RX_TIMEOUT);   
    
    return stat;
}

// close the TCP connection
BOOL Wizfi_CloseTCP(uint8_t linkID)
{
#if USE_SPRINF
    char cmdBuf[32];
    sprintf(cmdBuf, "AT+CIPCLOSE=%d\r\n", linkID);
    WizFi_Send_String(cmdBuf, DUPLEX_DELAY);" 
#else  
    WizFi_Send_String("AT+CIPCLOSE=", RX_TIMEOUT);
    WizFi_Send_Num_uint8(linkID, RX_TIMEOUT);
    WizFi_Send_String("\r\n", RX_TIMEOUT);             
#endif    
    
    databuffer_reset(&wifi_rxBuffer);
    stat=WizFi_getResp("OK",RX_TIMEOUT);   
    
    return stat;
}

/*
 * These are related to client mode...
 */
// connect to an AP
BOOL WizFi_APConnect(char *NetName, char *NetPasswd)
{
    // set the host name
    WizFi_Send_String("AT+CWMODE_CUR=1\r\n", DUPLEX_DELAY);
    stat=WizFi_getResp("OK",RX_TIMEOUT);
    
    // set mode to station
    WizFi_Send_String("AT+CWHOSTNAME=\"PUTSI-WiFi\"\r\n", DUPLEX_DELAY);
    stat=WizFi_getResp("OK",RX_TIMEOUT);
    
#if USE_SPRINF
    char cmdBuf[32];
    sprintf(cmdBuf, "AT+CWJAP=\"%s\",\"%s\"\r\n", NetName, NetPasswd);
    WizFi_Send_String(cmdBuf, DUPLEX_DELAY);" 
#else
    WizFi_Send_String("AT+CWJAP=\"", DUPLEX_DELAY);
    WizFi_Send_String(NetName, DUPLEX_DELAY);
    WizFi_Send_String("\",\"", DUPLEX_DELAY); 
    WizFi_Send_String(NetPasswd, DUPLEX_DELAY);
    WizFi_Send_String("\"\r\n", DUPLEX_DELAY);     
#endif
    
    databuffer_reset(&wifi_rxBuffer);
    stat=WizFi_getResp("OK", RX_TIMEOUT);   

    stat = WizFi_getResp("GOT IP", RX_TIMEOUT);
    return stat;
}

uint8_t WizFi_GetConnect_Status(void)
{
    databuffer_reset(&wifi_rxBuffer);
    WizFi_Send_String("AT+CIPSTATUS\r\n", DUPLEX_DELAY);
    stat=WizFi_getResp("STATUS:",RX_TIMEOUT);
    
    // get the status
    uint8_t c;
    while((c=databuffer_get(&wifi_rxBuffer)) == BUFFER_NO_DATA);
    return(c-'0');
}

// setup UDP mode to receive from server
BOOL Wizfi_UDPSetup(char *IPAddress, char *svrport, char *myport)
{
    // first set CIP mux off
    WizFi_Send_String("AT+CIPMUX=0\r\n", DUPLEX_DELAY);
    stat=WizFi_getResp("OK",RX_TIMEOUT);

    if(!stat)
        return FALSE;
    
#if USE_SPRINF
    char cmdBuf[32];
    sprintf(cmdBuf, "AT+CIPSTART=\"UDP\",\"%s\",%s,%s,0\r\n", IPAddress, svrport, myport);
    WizFi_Send_String(cmdBuf, DUPLEX_DELAY);" 
#else
    WizFi_Send_String("AT+CIPSTART=\"UDP\",\"", DUPLEX_DELAY);
    WizFi_Send_String(IPAddress, DUPLEX_DELAY);
    WizFi_Send_String("\",", DUPLEX_DELAY); 
    WizFi_Send_String(svrport, DUPLEX_DELAY);
    WizFi_Send_String(",", DUPLEX_DELAY); 
    WizFi_Send_String(myport, DUPLEX_DELAY);    
    WizFi_Send_String(",", DUPLEX_DELAY);     
    WizFi_Send_String("0\r\n", DUPLEX_DELAY);              
#endif
    databuffer_reset(&wifi_rxBuffer);
    stat=WizFi_getResp("OK",RX_TIMEOUT);    
    
    return stat;    
}

// send a command to send a UDP packet
BOOL Wizfi_Send_UDPData(size_t cmdLen, char *IPAddress, char *port)
{
#if USE_SPRINF
    char cmdBuf[32];
#ifdef UDP_SEND_ADDR
//  sprintf(cmdBuf, "AT+CIPSEND=%d,\"%s\",%s\r\n", cmdLen, IPAddress, port);
#else    
    sprintf(cmdBuf, "AT+CIPSEND=%d\r\n", cmdLen);
#endif
    databuffer_reset(&wifi_rxBuffer);    
    WizFi_Send_String(cmdBuf, DUPLEX_DELAY);" 
#else    
    databuffer_reset(&wifi_rxBuffer);
    WizFi_Send_String("AT+CIPSEND=", DUPLEX_DELAY);    
    WizFi_Send_Num_sizet(cmdLen, DUPLEX_DELAY);
#if UDP_SEND_ADDR
    WizFi_Send_String(",\"", DUPLEX_DELAY);
    WizFi_Send_String(IPAddress, DUPLEX_DELAY);      
    WizFi_Send_String("\",", DUPLEX_DELAY);
    WizFi_Send_String("port", DUPLEX_DELAY);
#endif
    WizFi_Send_String("\r\n", DUPLEX_DELAY);    
#endif
    
    stat=WizFi_getResp("OK",RX_TIMEOUT);
    return stat;
}

// send a byte to the wifi
void WizFi_Send_Byte(char c, uint8_t spacing)
{
    if(EUSART1_is_tx_ready())
        EUSART1_Write(c);
    delay(spacing);    
}

/*
 * Utility functions
 */

// send a string to the wifi
void WizFi_Send_String(char *cmd, uint8_t spacing)
{
    char c = *cmd;
    while(c) {
        WizFi_Send_Byte(c, spacing);
        cmd++;        
        c = *cmd;
    }
}

// send a string to the wifi
BOOL WizFi_Send_Uint8(uint8_t *cmd, size_t len, uint8_t spacing)
{
    databuffer_reset(&wifi_rxBuffer);
    uint8_t c = *cmd;
    
    while(len--) {
        WizFi_Send_Byte(c, spacing);
        cmd++;        
        c = *cmd;
    }
    
    stat=WizFi_getResp("bytes",RX_TIMEOUT);
    return stat;
}

// return number of bytes in buffer
uint8_t WizFi_BytesInBuffer(void)
{
    return wifi_rxBuffer.nBytes;
}

// get a char from the buffer
DATA_ELEMENT WizFi_get(void)
{
    return(databuffer_get(&wifi_rxBuffer));
}

BOOL WizFi_hasPacket(char *tag)
{
    DATA_ELEMENT c;
    
    while(EUSART1_is_rx_ready())   {
        c = EUSART1_Read();
        databuffer_put(c, &wifi_rxBuffer);
        if(databuffer_endswith(&wifi_rxBuffer,tag))
            return TRUE;       
    }
    return FALSE;
}

// get a response; or time out
BOOL WizFi_getResp(char *tag, uint8_t timeout)
{
    DATA_ELEMENT c;
    
    // prevent the ISR from decrementing while we update
    rxTimerLock = LOCKED;
    rxTimeOut = timeout;
    rxTimerLock = UNLOCKED;
    
    while(rxTimeOut)      {
        if(EUSART1_is_rx_ready())   {
            c = EUSART1_Read();
            databuffer_put(c, &wifi_rxBuffer);
            if(databuffer_endswith(&wifi_rxBuffer,tag))
                return TRUE;
        }
    }
     
    // here after timeout
    return FALSE;
}

// retreive a packet
BOOL WizFi_getPacket(uint8_t *packet, size_t size, uint8_t timeout)
{
    uint8_t c;
    
    // prevent the ISR from decrementing while we update
    rxTimerLock = LOCKED;
    rxTimeOut = timeout;
    rxTimerLock = UNLOCKED;
    
    while(rxTimeOut)      {
        if(EUSART1_is_rx_ready())   {
            c = EUSART1_Read();
            *packet++ = c;
            if(--size == 0)
                return TRUE;
        }
    }
     
    // here after timeout
    return FALSE;
}

// flush the buffer until a timeout
void flush_resp(uint8_t timeout)
{
    rxTimerLock = LOCKED;
    rxTimeOut = timeout;
    rxTimerLock = UNLOCKED;
    
    while(rxTimeOut)      {
        if(EUSART1_is_rx_ready())
            EUSART1_Read();        
    }
    
    return;
}

// replacement for sprintf
void WizFi_Send_Num_uint8(uint8_t num, uint8_t spacing)
{
    char buf[8];
    char *p = &buf[7];
    *p = '\0';
  do {
        *(--p) = digits[(num % DEC_BASE)];
         num /= DEC_BASE;
    } while (num != 0);
    WizFi_Send_String(p, spacing);
}

// send a 16 bit unsigned
void WizFi_Send_Num_sizet(size_t num, uint8_t spacing)
{
    char buf[8];
    char *p = &buf[7];
    *p = 0;
    do {
       *(--p) = digits[(num % DEC_BASE)];
        num /= DEC_BASE;
    } 	while (num != 0);
    WizFi_Send_String(p, spacing);
}

// timer is called from ISR every 10 ms
void WizFi_rx_timer(void)
{
    if(rxTimerLock)
        return;
    
    if(rxTimeOut > 0)
        rxTimeOut--;
}

/**
 *  Wifi Thru mode. Connect the USB to the serial port.
 *  Debug mode only: not for general use 
 **/
void Wizfi_Thru_Mode(void)
{
    DATA_ELEMENT c;

#if USB_TEST  
    // USB loopback test
    uint8_t nData = 0;
    while((c=databuffer_get_small(&usb_rxBuffer)) != BUFFER_NO_DATA)    {
        WifiUSBBuffer[nData++] = c;
    }
    if(nData)   {
        while(!USBUSARTIsTxTrfReady());
        putUSBUSART(WifiUSBBuffer,nData); 
   }    
#else    
    // USB->>UART
    while((c=databuffer_get_small(&usb_rxBuffer)) != BUFFER_NO_DATA)    {
        WizFi_Send_Byte(c, DUPLEX_DELAY);
    }

    // UART->>USB
    if(EUSART1_is_rx_ready())   {
        c = EUSART1_Read();
        WifiUSBBuffer[usbCnt++] = c;
        if(c == '\n')   {
            WifiUSBBuffer[usbCnt] = '\0';      // terminate with a NULL
            putUSBUSART(WifiUSBBuffer, usbCnt);
            usbCnt = 0;
        }
    }
    
#endif    

}
