/*---------------------------------------------------------------------------
	Project:	      PUTSI WiFi

	Module:		      Mainline

	File Name:	      main.c

	Author:		      Martin C. Alcock, VE6VH

	Revision:	      1.0

	Description:      Mainline for PIC application

            		  Copyright (c) 2018-2022 Praebius Communications Inc.

	Revision History:

---------------------------------------------------------------------------*/

#include "mcc_generated_files/mcc.h"
#include "putsi.h"

// test modes
#define         WIFI_TEST       0       // Wifi test mode
#define         ENA_USB_TEST    0       // enable USB test mode

#define         MAX_CONNECT     10      // max connect retries

// internals
void Config_Mode(void);
void USB_Thru_Mode(void);

void main(void)
{
    BOOL SetupValid = FALSE;        // setup data is valid
    
    // Initialize the device
    SYSTEM_Initialize();

    // init application layer
    databuffer_init_small(&usb_rxBuffer);
    databuffer_init(&wifi_rxBuffer);
    PIN_MANAGER_IOC();
    
    // retrieve the setup data from EEProm
    SetupValid = init_setup();
    
    // start the USB mode: if enabled
    InitUSBMode(Get_IO_Data());    

    // initialize the peripherals
    COMLed_init();
    timerStart();
    InitPollTimer();
    
    EUSART1_Initialize();

    INTERRUPT_GlobalInterruptEnable();
    INTERRUPT_PeripheralInterruptEnable();
    
    /*
     * Soft reset to Wifi part
     */
    WizFi_Init();
   
    /**
     * Forced configuration mode
     * Enter if jumper installed or
     * Setup was defaulted or
     * Wifi or USB modes are not enabled
     */
    if(InConfigMode() || !SetupValid || (!isWifiEnabled() && !isUSBEnabled()))  {
        Config_Mode();
    }

    // if wifi is not enabled shut off the ap mode
    if(!isWifiEnabled())
       WizFi_ClientSetup();    
    
#if ENA_USB_TEST   
    /**
     * Loop for pass through mode
     * Test mode for Wifi development
     */
    if(InThruMode())
        USB_Thru_Mode();
#endif
        
    /*
     * Startup of Wifi operations
     * If enabled, try to connect to AP
     * Turn on the conn LED if we are
     * Enter autoconfig if connection fails
     */
    if(isWifiEnabled())       {
        BOOL connected=FALSE;
        uint8_t retries = MAX_CONNECT;
        while(retries--)   {
            connected=USRP_Init();
            if(connected)
                break;
            delay(10);
        }
        // if there is no connection and autoconfig is enabled
        // enter the configuration mode
        if(!connected && isAutoConfigEnabled())
            Config_Mode();
        
        // connected; assume normal operation
        COMLed_SetWifiStatus(connected);  // update the Wifi Status
        USRP_Start();                     // start the conversation
    }

    // always start the ADC and I/O tasks; but after interrupts are enabled
    ADC_Task_Start();                 // start the ADC conversion
    IO_Task_Start();                  // start the pin I/O task
    
#if WIFI_TEST
    USB_Thru_Mode();            // use through mode to send
#else 
    
    // main loop
    while(TRUE)     {
        IO_DATA *io_data = Get_IO_Data();
        ADC_Conv_Update(io_data);       // update the current ADC           
        IO_Get_Inputs();
        
        // wifi mode: send/receive a UDP packet 
        if(isWifiEnabled())     {
            if(USRP_Get_Timer())
                USRP_SendPacket(io_data);
            if(USRP_hasRxPacket())  {
                USRP_GetPacket(io_data);
            }
        }
        
        // usb mode: exchange data with Allstar
        if(isUSBEnabled())      {
            USB_Rx();                
            DAQMsgRx();
            if(isUSBTxEnabled())
                IO_Gen_PinMsgs();
            if(USB_Get_Timer())
                DAQMsgTx();
            CDCTxService();                       
        }
        
        // update outputs in both cases
        IO_Set_Outputs();        
        delay(10);                 // delay 5 ms
    }
#endif       
}

/*
 * HTTP setup mode
 * Wait for a connection, then
 * respond with the page
 * get the response
 * store it to the flash
 * rinse and repeat...
 */
void Config_Mode(void)
{
    WizFi_APSetup();
    COMLed_SetConfigStatus(TRUE);
    while(1)    {
        if(WizFi_getHTMLReq())
            if(ProcessHTMLPageReq())
                Write_Setup();
            GenHTML();
    }
}

/*
 * USB Thru mode
 * Useful for testing...
 */
void USB_Thru_Mode(void)
{
    while (1)  {
        USB_Rx();
        Wizfi_Thru_Mode();
        CDCTxService();        
    }
}

/**
 End of File
*/