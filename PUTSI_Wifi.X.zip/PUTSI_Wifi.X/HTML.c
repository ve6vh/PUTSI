/*---------------------------------------------------------------------------
	Project:	      PUTSI WiFi

	Module:		      HTML processor for setup page

	File Name:	      HTML.c

	Author:		      Martin C. Alcock, VE6VH

	Revision:	      1.0

	Description:      Mainline for PIC application

            		  Copyright (c) 2018-2022 Praebius Communications Inc.

	Revision History:

---------------------------------------------------------------------------*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "putsi.h"

// test mode
#define HTML_TEST           0           // in test mode
#define LONG_MESSAGE        1           // long HTML message
#define INCLUDE_PORTS       0           // include port numer
#define INCLUDE_AUTOCONFIG  0           // include autoconfig

// long message and options
#if LONG_MESSAGE
#define N_BASE_MESSAGES     41          // base messages for long message

#if INCLUDE_PORTS
#define N_PORT_MESSAGES     8           // adder for port #messages
#else
#define N_PORT_MESSAGES     0           // no adder for ports
#endif

#if INCLUDE_AUTOCONFIG
#define N_AUTO_MESSAGES     5           // number of autoconfig
#else
#define N_AUTO_MESSAGES     0           // no adder for auto
#endif
// end of long messages
#else
// short message (no options)
#define N_BASE_MESSAGES     18          // base messages for short message
#define N_PORT_MESSAGES     0           // no adder for ports
#define N_AUTO_MESSAGES     0           // number of autoconfig
#endif

#define N_HTMLSTRINGS       (N_BASE_MESSAGES+N_PORT_MESSAGES+N_AUTO_MESSAGES)

#define DEF_LINK_ID         0           // default link ID

// HTML Variables
#define VAR_IPADDRESS       0           // IP address
#define VAR_SERVERPORT      1           // server port
#define VAR_LOCALPORT       2           // local port
#define VAR_RADIOID         3           // radio ID
#define VAR_INTERVAL        4           // Interval
#define VAR_NETNAME         5           // network name
#define VAR_NETPASSWD       6           // network password
#define VAR_WIFIMODE        7           // wifi enabled
#define VAR_USBMODE         8           // USB enabled
#define VAR_AUTOCONFIG      9           // Autoconfig enabled
#define NUM_VARS            10          // number of variables

// checkbox values
#define UNCHECKED           0           // not checked
#define CHECKED             1           // checked

// internals
uint8_t CharInString(char c, char *String);
BOOL UpdateVariable(char name[], char value[]);

// variable names: must agree with HTML id= parameter
char *varNames[NUM_VARS] = {
    "IP",
    "ServerPort",
    "LocalPort",
    "ID",
    "Int",
    "NetName",
    "NetPwd",
    "wifi",
    "usb",
    "conf"
};

const char *checkBox[] = {
    "unchecked",
    "checked"
};

// HTML strings for page
const char *htmlStrings[] = {
    "HTTP/1.0 200 OK\r\n",
    "Content-type: text/html\r\n",
    "\r\n",
    "<!DOCTYPE html>\r\n",
    "<html>\r\n",
    "<body>\r\n",
    "<h2>PUTSI Wifi Setup</h2>\r\n",
    "<form>\r\n",
    "<table>\r\n",
      "<tr>\r\n",
            "<td><label>Server IP Address:</label>&nbsp;&nbsp;</td>\r\n",
            "<td><input type=\"text\" id=\"IP\" name=\"IP\" value=\"@I\"><br><br></td>\r\n",
      "</tr>\r\n",
#if LONG_MESSAGE     
#if INCLUDE_PORTS
      "<tr>\r\n",
            "<td><label>Server Port:      </label></td>\r\n",
            "<td><input type=\"text\" id=\"ServerPort\" name=\"ServerPort\" value=\"@P\"><br><br></td>\r\n",
      "</tr>\r\n",
      "<tr>\r\n",
            "<td><label>Local Port:      </label></td>\r\n",
            "<td><input type=\"text\" id=\"LocalPort\" name=\"LocalPort\" value=\"@L\"><br><br></td>\r\n",
      "</tr>\r\n"
#endif
      "<tr>\r\n",
            "<td><label>Radio ID:         </label></td>\r\n",
            "<td><input type=\"text\" id=\"ID\" name=\"ID\" value=\"@R\"><br><br></td>\r\n",
      "</tr>\r\n",
      "<tr>\r\n",
            "<td><label>Network Name:      </label></td>\r\n",
            "<td><input type=\"text\" id=\"NetName\" name=\"NetName\" value=\"@A\"><br><br></td>\r\n",
      "</tr>\r\n",    
      "<tr>\r\n",
            "<td><label>Password:         </label></td>\r\n",
            "<td><input type=\"password\" id=\"NetPwd\" name=\"NetPwd\" value=\"@W\"><br><br></td>\r\n",
      "</tr>\r\n",    
      "<tr>\r\n",
            "<td><label>Reporting Interval:</label></td>\r\n",
            "<td><input type=\"number\" id=\"Int\" name=\"Int\" value=\"@V\"><br><br></td>\r\n",
      "</tr>\r\n",
      "<tr>\r\n",
            "<td><br><input type=\"checkbox\" name=\"wifi\" @w >\r\n",
			"Enable WiFi mode&nbsp;&nbsp;\r\n",
			"<input type=\"checkbox\" name=\"usb\" @u >\r\n",
			"Enable USB mode\r\n",			
		    "</td>\r\n",
      "</tr>\r\n",
#if INCLUDE_AUTOCONFIG
      "<tr>\r\n",
            "<td><br><input type=\"checkbox\" name=\"conf\" @c >\r\n",
			"Auto Config Enabled\r\n",
		    "</td>\r\n",
      "</tr>\r\n",    
#endif    
#endif 
    "</table>\r\n",
    "<br>&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"Submit\">\r\n",  
    "</form>\r\n",
    "</body>\r\n",
    "</html>\r\n"
};

/*
 * HTML Page generator
 */
BOOL GenHTML(void)  {
    BOOL stat;
    
#if HTML_TEST
    // generate the response command: "hello world"
    char *cmd = "HTTP/1.0 200 OK\r\nContent-type: text/html\r\nConnection: close\r\n\r\n<!DOCTYPE html>\r\n<html>\r\n<body>\r\nHello world from PUTSI</body>\r\n</html>\r\n";
    //                                                                                                                             1
    //                     1         2         3            4            5           6           7           8         9           0     
    //           012345678901234 5 678901234567890123456789 0 1 2 3456789012345678 9 0123456 7 89012345 6 789012345678901234 5 678901234 5 6
   
    uint8_t cmdLen = strlen(cmd);
    
    if(!Wizfi_Send_TCPData(DEF_LINK_ID, cmdLen))
        return FALSE;
    
    for(uint8_t i=0;i<cmdLen;i++)
        WizFi_Send_StringByte(cmd[i], DUPLEX_DELAY);
    
    stat=WizFi_getResp("OK",RX_TIMEOUT);  
    
    if(stat)    {
        stat=Wizfi_CloseTCP(DEF_LINK_ID);
    }
    
    return stat;
    
#else
    SETUP_DATA *setup = Get_Setup();
    size_t cmdLen = 0;
    uint8_t nCmds = N_HTMLSTRINGS, i;
    
    // calculate the length of the string first    
    for(i=0;i<nCmds;i++) 
        cmdLen += strlen(htmlStrings[i]);
    
    // add length of setup struct, less delimeters
    cmdLen += strlen(setup->IPAddress) - 2;
#if INCLUDE_PORTS    
    cmdLen += strlen(setup->SvrPort) - 2;
    cmdLen += strlen(setup->LclPort) - 2;
#endif
    cmdLen += strlen(setup->RadioID) - 2;
    cmdLen += strlen(setup->Interval) - 2;
    cmdLen += strlen(setup->NetName) - 2;
    cmdLen += strlen(setup->NetPwd) - 2;
    cmdLen += setup->flags.WiFiEnabled ? strlen(checkBox[CHECKED]) - 2 : strlen(checkBox[UNCHECKED]) - 2;
    cmdLen += setup->flags.USBEnabled ? strlen(checkBox[CHECKED]) - 2 : strlen(checkBox[UNCHECKED]) - 2;
#if INCLUDE_AUTOCONFIG    
    cmdLen += setup->flags.AutoConfig ? strlen(checkBox[CHECKED]) - 2 : strlen(checkBox[UNCHECKED]) - 2;
#endif
    
    // generate the response command
    if(!Wizfi_Send_TCPData(DEF_LINK_ID, cmdLen))
        return FALSE;

    for(i=0;i<nCmds;i++)    {
    
        uint8_t htmllen;
        char *html = (char *)htmlStrings[i];
        htmllen = (uint8_t)(strlen(html) & 0xff);

        while(*html)  {
            // process a delimeter field
            if(*html == '@')    {
                html++;
                switch(*html)       {
                    
                    case 'I':
                        WizFi_Send_String(&setup->IPAddress[0], DUPLEX_DELAY);
                        break;
                        
                    case 'P':
                        WizFi_Send_String(&setup->SvrPort[0], DUPLEX_DELAY);
                        break;
                        
                    case 'L':
                        WizFi_Send_String(&setup->LclPort[0], DUPLEX_DELAY);
                        break;                        
                        
                    case 'R':
                        WizFi_Send_String(&setup->RadioID[0], DUPLEX_DELAY);
                        break;
                        
                    case 'V':
                        WizFi_Send_String(&setup->Interval[0], DUPLEX_DELAY);
                        break;
                        
                    case 'A':
                        WizFi_Send_String(&setup->NetName[0], DUPLEX_DELAY);
                        break;                        
                        
                    case 'W':
                        WizFi_Send_String(&setup->NetPwd[0], DUPLEX_DELAY);
                        break;

                    case 'w':
                        if(setup->flags.WiFiEnabled)
                            WizFi_Send_String((char *)checkBox[CHECKED], DUPLEX_DELAY);
                        else
                            WizFi_Send_String((char *)checkBox[UNCHECKED], DUPLEX_DELAY);
                        break;
                        
                    case 'u':
                        if(setup->flags.USBEnabled)
                            WizFi_Send_String((char *)checkBox[CHECKED], DUPLEX_DELAY);
                        else
                            WizFi_Send_String((char *)checkBox[UNCHECKED], DUPLEX_DELAY);
                        break; 
                        
                    case 'c':
                        if(setup->flags.AutoConfig)
                            WizFi_Send_String((char *)checkBox[CHECKED], DUPLEX_DELAY);
                        else
                            WizFi_Send_String((char *)checkBox[UNCHECKED], DUPLEX_DELAY);
                        break;                         
                            
                }
            }
            // not a delimeter
            else {
                WizFi_Send_Byte(*html, DUPLEX_DELAY); 
            }
            html++;
        }
    }
#endif
    WizFi_getResp("OK",RX_TIMEOUT);  
    stat=Wizfi_CloseTCP(DEF_LINK_ID);

    return stat;
}

static BOOL WifiChecked=FALSE, USBChecked=FALSE, AutoConfigChecked=FALSE; 

/*
 * HTML page parser
 */
/*	Parse an incoming message		*/
//	this is machine generated, so we don't have to be too fancy....
BOOL ProcessHTMLPageReq(void)
{
    char c, *InputPtr;
    char TextEntry[64];
    uint8_t pos;
    BOOL pageHasArgs = FALSE;
   
    WifiChecked=FALSE, USBChecked=FALSE, AutoConfigChecked=FALSE; 

	InputPtr=&TextEntry[0];		// Reset parse pointer
    
	while(WizFi_BytesInBuffer())		{

	    c=(char)WizFi_get();
	    switch(c) {

            case '?' :                      // HTML page name
                InputPtr=&TextEntry[0];		// Reset parse pointer
                pageHasArgs=TRUE;
                break;

            case '&':               // Field delimiter
            case ' ':
            case BUFFER_NO_DATA:	// End of field or pagename
                pageHasArgs=TRUE;
                *InputPtr='\0';
                // has a value attached
                if((pos=CharInString('=', TextEntry)) != 0)   {
                    TextEntry[pos] = '\0';
                    UpdateVariable(TextEntry, &TextEntry[pos+1]);
                }
                InputPtr=&TextEntry[0];	
                if(c == BUFFER_NO_DATA)
                    break;
            break;

            default :
                if(c > ' ')
                    *InputPtr++=c;
            break;
        }
	}
    
    // update check boxes before leaving
    if(pageHasArgs)     {
        SETUP_DATA *setup = Get_Setup();
        setup->flags.WiFiEnabled = WifiChecked;
        setup->flags.USBEnabled = USBChecked;
#if INCLUDE_AUTOCONFIG        
        setup->flags.AutoConfig = AutoConfigChecked;
#else
    setup->flags.AutoConfig = WifiChecked;        
#endif        
    }
    return pageHasArgs;
}

// find a char in a string
uint8_t CharInString(char c, char *String)
{
    uint8_t pos=0;
    while(*String)  {
        if(c == *String)
            return pos;
        String++;
        pos++;
    }
    return 0;
}

BOOL UpdateVariable(char name[], char value[])
{
    uint8_t varnum;
    SETUP_DATA *setup = Get_Setup();
 
    for(varnum=0; varnum < NUM_VARS; varnum++)   {
        if(!strcmp(name, varNames[varnum]))     {
            switch(varnum)      {
                
                case VAR_IPADDRESS:
                    strcpy(setup->IPAddress, value);
                    return TRUE;
                   
                case VAR_SERVERPORT:
                    strcpy(setup->SvrPort, value);
                    return TRUE;
                    
                case VAR_LOCALPORT:
                    strcpy(setup->LclPort, value);
                    return TRUE;
                    
                case VAR_RADIOID:
                    strcpy(setup->RadioID, value);
                    return TRUE;
                    
                case VAR_INTERVAL: 
                    strcpy(setup->Interval, value);
                    return TRUE;
                    
                case VAR_NETNAME:
                    strcpy(setup->NetName, value);
                    return TRUE;
                    
                case VAR_NETPASSWD:
                    strcpy(setup->NetPwd, value);
                    return TRUE;
                    
                case VAR_WIFIMODE:
                    WifiChecked = TRUE;
                    return TRUE;
                    
                case VAR_USBMODE:
                    USBChecked = TRUE;
                    return TRUE;
                    
                case VAR_AUTOCONFIG:
                    AutoConfigChecked = TRUE;
                    return TRUE;
            }
        }
    }
    return FALSE;
}