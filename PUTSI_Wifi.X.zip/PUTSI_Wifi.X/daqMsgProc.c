/*---------------------------------------------------------------------------
	Project:	      PUTSI WiFi

	Module:		      Process a USB command

	File Name:	      daqMsgProc.c
 * 
	Revision:	      0.02

	Description:      Header file for PUTSI project

                      This software module and all others are the exclusive property of the Alberta Digital 
                      Radio Communications Society and others (?the owners?), all rights are reserved.

                      The owners grant licence to any Amateur for personal or club use, and only on hardware
                      designed by them expressly for this purpose, use on any other hardware is prohibited.
 
                      This file, and others may be copied or distributed only with the inclusion of this 
                      notice.

                      No warranty, either express or implied or transfer of rights is granted in this 
                      licence and the owner is not liable for any outcome whatsoever arising from such usage.

                      Copyright � 2023, Alberta Digital Radio Communications Society


	Revision History:

---------------------------------------------------------------------------*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "putsi.h"
#include "daq.h"

// for message processor
#define	DELIMCHR	','
#define	QUOTECHR	34

struct daqcmds_t {
	char	*cmd;
	int		type;
};

// main commands
const struct daqcmds_t daqCmds[N_CMDS] = {
    { "reset", CMD_RESET },
	{ "id", CMD_ID },
	{ "led", CMD_LED },
	{ "pin", CMD_PIN},
	{ "adc", CMD_ADC }

};

// Pin commands
const struct daqcmds_t pinCmds[N_PIN_CMDS] = {
	{ "in", PIN_IN },
	{ "out", PIN_OUT },
	{ "monitor", PIN_MON },
	{ "pullup", PIN_PULLUP },
	{ "lo", PIN_LO},
	{ "hi", PIN_HI }
};

// command arguments
#define DAQ_CMD				0		// DAQ command location
#define	PIN_NO				1		// pin number argument
#define	PIN_CMD				2		// command code
#define	PIN_ARG				3		// optional argument
#define	MIN_PIN_ARGS		3		// minimum arguments in a pin command
#define MIN_ADC_ARGS		2		// min args for an ADC command
#define	MAX_ARGS			7		// max args in a string

char *argv[MAX_ARGS];			// vector of arguments

// internals
uint8_t finddelim(char *str, char *strp[], int limit);
uint8_t explode_string(char *str, char *strp[], int limit, char delim, char quote);
void processPinCmd(DAQ_THREADS *t, int argc, char *argv[]);
uint8_t processADCCmd(DAQ_THREADS *t, int argc, char *argv[]);

void daqMsgProc(DAQ_THREADS *t)
{
    STACK_ELEMENT ret_msg;
    uint8_t adcChan = 0;
	uint8_t argc = explode_string((char *)t->msgBuffer, argv, MAX_ARGS, ' ', 0);

	for (int i = 0; i < N_CMDS; i++) {
		if (!strcmp(daqCmds[i].cmd, argv[DAQ_CMD])) {

			switch (daqCmds[i].type) {

            // reset machines
            case CMD_RESET:
                stopDAQTx();
                return;                                    
                    
			case CMD_ID:
                stopDAQTx();
				ret_msg.item = MK_ELEMENT(MSG_INT, INT_ID);
				EnQueMsg(ret_msg, TX_OFF);
				break;

			case CMD_LED:
				ret_msg.item = MK_ELEMENT(MSG_INT, INT_NULL);
				EnQueMsg(ret_msg, TX_ON);     
				break;

			case CMD_PIN:
				processPinCmd(t, argc, argv);
				break;

			case CMD_ADC:          //TBD
				if((adcChan = processADCCmd(t, argc, argv)) == 0)
                    return;
                ret_msg.desig.index = adcChan;
                ret_msg.desig.type = MSG_ADC;
				EnQueMsg(ret_msg, TX_ON);       
                StartPollTimer();
				break;

			default:
				break;
			}
			return;
		}
	}
	// fell off the end
}

/*
        Retrieve the pin type
 */
uint8_t getPinDef(uint8_t pinNumber)
{
    if(ISADC(pinNumber))
        return PIN_ADC;
    if(ISINPUT(pinNumber))
        return PIN_IN;
    if(ISOUTPUT(pinNumber))
        return PIN_OUT;
    
    return PIN_UNK;
}

/*
	Function:		Process a pin command

	Inputs:			char * message buffer

	Outputs:		updated pin status

	Description:	process a pin command
*/
void processPinCmd(DAQ_THREADS *t, int argc, char *argv[])
{
	if (argc < MIN_PIN_ARGS)
		return;

	// get the data for the pin
	uint8_t pinNumber = A2_uint8_t(argv[PIN_NO]);
	uint8_t pinType = getPinDef(pinNumber);
    uint8_t pinNum;

	for (int i = 0; i < N_PIN_CMDS; i++) {
		if (!strcmp(pinCmds[i].cmd, argv[PIN_CMD])) {

			switch (pinCmds[i].type) {

            // these are basically ignored...
			case PIN_IN:
			case PIN_OUT:
			case PIN_PULLUP:
    			break;

            // set pin monitor state
			case PIN_MON:
                pinNum = INPUT_INDEX(pinNumber);
                if(pinType != PIN_IN)
                    break;                  // not an input pin
				if (!strcmp(argv[PIN_ARG], "off")) {
                    t->ioData->digIn_data[pinNum].MON = FALSE;
				}
				else {
					if (!strcmp(argv[PIN_ARG], "on")) {
                        t->ioData->digIn_data[pinNum].MON = TRUE;
					}
				}
				break;

            // toggle an output low if it is not currently in that state
            case PIN_LO:
                pinNum = OUTPUT_INDEX(pinNumber);                    
				if (pinType == PIN_OUT) {
                    if(t->ioData->digOut_data[pinNum].STATE != PIN_STATE_OFF)     {
                        t->ioData->digOut_data[pinNum].STATE = PIN_STATE_OFF;
                        t->ioData->digOut_data[pinNum].UPDATE = TRUE;                        
                    }
                }
				break;

			case PIN_HI:
                pinNum = OUTPUT_INDEX(pinNumber);                    
				if (pinType == PIN_OUT) {
                    if(t->ioData->digOut_data[pinNum].STATE != PIN_STATE_ON)     {
                        t->ioData->digOut_data[pinNum].STATE = PIN_STATE_ON;
                        t->ioData->digOut_data[pinNum].UPDATE = TRUE;                        
                    }
                }
				break;

			}
			return;
		}
	}

	// fell off the end
}

// process an ADC Command
uint8_t processADCCmd(DAQ_THREADS *t, int argc, char *argv[])
{
	if (argc < MIN_ADC_ARGS)
		return 0;

	// get the data for the pin
	uint8_t pinNumber = A2_uint8_t(argv[PIN_NO]);
    
    return pinNumber;
}

/*---------------------------------------------------------------------------

	FUNCTION:	explode_string

	INPUTS:		command line

	OUTPUTS:	number of substrings found

	DESCRIPTION:	Break up a delimited string into a table of substrings

	str - delimited string ( will be modified )
	strp- list of pointers to substrings (this is built by this function),
			NULL will be placed at end of list
	limit- maximum number of substrings to process
	delim- user specified delimeter
	quote- user specified quote for escaping a substring. Set to zero to escape nothing.

	Note: This modifies the string str, be sure to save an intact copy if you need it later.

	(Borrowed from Allstar)
-------------------------------------------------------------------------- - */
uint8_t finddelim(char *str, char *strp[], int limit)
{
	return explode_string(str, strp, limit, DELIMCHR, QUOTECHR);
}

uint8_t explode_string(char *str, char *strp[], int limit, char delim, char quote)
{
	uint8_t     i, l, inquo;

	inquo = 0;
	i = 0;
	strp[i++] = str;
	if (!*str)
	{
		strp[0] = 0;
		return(0);
	}
	for (l = 0; *str && (l < limit); str++)
	{
		if (quote)
		{
			if (*str == quote)
			{
				if (inquo)
				{
					*str = 0;
					inquo = 0;
				}
				else
				{
					strp[i - 1] = str + 1;
					inquo = 1;
				}
			}
		}
		if ((*str == delim) && (!inquo))
		{
			*str = 0;
			l++;
			strp[i++] = str + 1;
		}
	}
	strp[i] = 0;
	return(i);
}